export const COMPANY = {
  name: "Lifema Seguros",
  shortName: "Lifema",
  legalName: "Lifema Corretora de Seguros",
  tagline: "Proteção para o que realmente importa",
  description:
    "Corretora de seguros brasileira. Soluções personalizadas em seguro auto, residencial, vida, empresarial, saúde, viagem, moto, caminhão e frotas.",
  phone: "(00) 00000-0000",
  phoneRaw: "00000000000",
  whatsapp: "(00) 00000-0000",
  whatsappNumber: "5500000000000",
  whatsappDefaultMessage: "Olá, vim pelo site e gostaria de solicitar uma cotação de seguro.",
  email: "adriano@lifemaseguros.com.br",
  address: "Av. Exemplo, 000 - Centro, Campinas - SP",
  mapsUrl: "https://maps.google.com/?q=Av.+Exemplo,+000+-+Centro,+Campinas+-+SP",
  social: {
    instagram: "https://instagram.com",
    facebook: "https://facebook.com",
    twitterHandle: "@lifemaseguros",
  },
  quoteUrl: "/#contato",
};

import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Header } from "../components/Header";
import { Hero } from "../components/Hero";
import { About } from "../components/About";
import { InsuranceGrid } from "../components/InsuranceGrid";
import { Benefits } from "../components/Benefits";
import { ProcessSteps } from "../components/ProcessSteps";
import { CtaBand } from "../components/CtaBand";
import { Testimonials } from "../components/Testimonials";
import { BlogCards } from "../components/BlogCards";
import { FAQ } from "../components/FAQ";
import { Contact } from "../components/Contact";
import { Footer } from "../components/Footer";
import { PrivacyModal } from "../components/PrivacyModal";
import { TermsModal } from "../components/TermsModal";

export const Route = createFileRoute("/")({
  component: HomeComponent,
  head: () => ({
    meta: [
      { title: "Lifema Seguros | Corretora de Seguros no Brasil" },
      {
        name: "description",
        content:
          "Lifema Seguros é uma corretora brasileira especializada em seguros para pessoas, famílias e empresas. Cote seguro auto, residencial, vida e mais.",
      },
      { property: "og:title", content: "Lifema Seguros | Corretora de Seguros no Brasil" },
      {
        property: "og:description",
        content:
          "Proteção completa para você, sua família e sua empresa. Atendimento personalizado e cotação rápida.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
});

function HomeComponent() {
  const [privacyOpen, setPrivacyOpen] = useState(false);
  const [termsOpen, setTermsOpen] = useState(false);

  return (
    <div className="min-h-screen bg-navy text-cream overflow-x-hidden w-full max-w-full">
      <Header />
      <main className="overflow-x-hidden w-full max-w-full">
        <Hero />
        <About />
        <InsuranceGrid />
        <Benefits />
        <ProcessSteps />
        <CtaBand />
        <Testimonials />
        <BlogCards />
        <FAQ />
        <Contact />
      </main>
      <Footer onPrivacy={() => setPrivacyOpen(true)} onTerms={() => setTermsOpen(true)} />
      <PrivacyModal open={privacyOpen} onClose={() => setPrivacyOpen(false)} />
      <TermsModal open={termsOpen} onClose={() => setTermsOpen(false)} />
    </div>
  );
}

import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { Header } from "../../components/Header";
import { Footer } from "../../components/Footer";
import { PrivacyModal } from "../../components/PrivacyModal";
import { TermsModal } from "../../components/TermsModal";
import { blogPosts, type BlogPost } from "../../data/blogPosts";
import { Calendar, Clock, Search, ArrowRight, BookOpen, ChevronRight } from "lucide-react";
import { cn } from "../../lib/utils";

export const Route = createFileRoute("/blog/")({
  component: BlogListPage,
  head: () => ({
    meta: [
      { title: "Blog | Lifema Seguros — Dicas e Guias de Seguros" },
      {
        name: "description",
        content:
          "Leia artigos e guias práticos sobre Seguro Auto, Residencial, Vida, Empresarial e dicas de proteção financeira da Lifema Seguros.",
      },
      { property: "og:title", content: "Blog & Artigos | Lifema Seguros" },
      {
        property: "og:description",
        content:
          "Informação é proteção. Descubra os melhores conteúdos para proteger sua família, patrimônio e negócios.",
      },
    ],
  }),
});

const categories = [
  "Todos",
  "Seguro Auto",
  "Seguro Residencial",
  "Seguro de Vida",
  "Seguro Empresarial",
  "Seguro Saúde",
  "Seguro Viagem",
  "Seguro Moto",
  "Seguro Caminhão",
  "Seguro para Frotas",
  "Dicas",
];

function BlogListPage() {
  const [selectedCategory, setSelectedCategory] = useState("Todos");
  const [searchQuery, setSearchQuery] = useState("");
  const [privacyOpen, setPrivacyOpen] = useState(false);
  const [termsOpen, setTermsOpen] = useState(false);

  const filteredPosts = blogPosts.filter((post) => {
    const matchesCategory =
      selectedCategory === "Todos" || post.category === selectedCategory;
    const matchesSearch =
      post.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      post.excerpt.toLowerCase().includes(searchQuery.toLowerCase()) ||
      post.category.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const featuredPost = blogPosts[0];

  return (
    <div className="min-h-screen bg-navy text-cream">
      <Header />

      <main className="pt-24 sm:pt-32">
        {/* Blog Hero Section */}
        <section className="relative overflow-hidden border-b border-white/10 bg-gradient-to-b from-navy-light/60 to-navy py-12 sm:py-16 md:py-20 lg:py-24">
          <div className="absolute -left-40 top-10 h-96 w-96 rounded-full bg-gold/10 blur-[120px]" />
          <div className="relative mx-auto max-w-7xl px-4">
            <div className="flex flex-col items-center text-center">
              <span className="mb-3 sm:mb-4 inline-flex items-center gap-2 rounded-full border border-gold/30 bg-gold/10 px-3.5 py-1 sm:px-4 sm:py-1.5 text-xs font-semibold uppercase tracking-wider text-gold">
                <BookOpen className="h-4 w-4" />
                Blog & Conteúdo
              </span>
              <h1 className="font-display text-3xl font-extrabold leading-tight text-cream sm:text-4xl md:text-5xl lg:text-6xl text-balance">
                Informação que gera <span className="text-gold">proteção</span>.
              </h1>
              <p className="mt-3 sm:mt-4 max-w-2xl text-base sm:text-lg md:text-xl text-slate">
                Confira nossos artigos, guias e dicas práticas para tirar dúvidas sobre apólices, coberturas e cuidar do que é seu.
              </p>

              {/* Search input */}
              <div className="mt-6 sm:mt-8 flex w-full max-w-lg items-center rounded-xl border border-white/15 bg-navy-light px-3.5 py-2.5 sm:px-4 sm:py-3 shadow-xl focus-within:border-gold/60">
                <Search className="h-4 w-4 sm:h-5 sm:w-5 text-slate shrink-0" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Pesquisar por assunto, seguro ou palavra..."
                  className="ml-2.5 sm:ml-3 w-full bg-transparent text-xs sm:text-sm text-cream placeholder-slate/60 outline-none"
                />
              </div>
            </div>
          </div>
        </section>

        {/* Category Filters */}
        <section className="border-b border-white/5 bg-navy/80 py-4 sm:py-6 sticky top-[72px] sm:top-[80px] z-30 backdrop-blur-md">
          <div className="mx-auto max-w-7xl px-4">
            <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1 sm:pb-0 sm:flex-wrap sm:justify-center">
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={cn(
                    "whitespace-nowrap rounded-full px-3.5 py-1.5 sm:px-4 sm:py-2 text-xs sm:text-sm font-semibold transition-all shrink-0",
                    selectedCategory === cat
                      ? "bg-gold text-navy shadow-md shadow-gold/20"
                      : "border border-white/10 bg-navy-light/50 text-cream/80 hover:border-gold/40 hover:text-cream"
                  )}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>
        </section>

        {/* Featured Post (only when "Todos" and no search query) */}
        {selectedCategory === "Todos" && !searchQuery && featuredPost && (
          <section className="py-8 sm:py-12 lg:py-16">
            <div className="mx-auto max-w-7xl px-4">
              <span className="mb-4 sm:mb-6 inline-block text-xs font-semibold uppercase tracking-wider text-gold">
                ★ Artigo em Destaque
              </span>
              <div className="grid gap-6 sm:gap-8 overflow-hidden rounded-3xl border border-white/10 bg-navy-light lg:grid-cols-12 lg:gap-0">
                <div className="relative h-56 sm:h-72 lg:col-span-7 lg:h-full overflow-hidden">
                  <img
                    src={featuredPost.image}
                    alt={featuredPost.title}
                    className="h-full w-full object-cover transition-transform duration-700 hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-navy-light via-transparent to-transparent lg:bg-gradient-to-r" />
                  <span className="absolute left-4 top-4 sm:left-6 sm:top-6 rounded-full bg-gold px-2.5 py-0.5 sm:px-3 sm:py-1 text-xs font-bold text-navy">
                    {featuredPost.category}
                  </span>
                </div>
                <div className="flex flex-col justify-between p-5 sm:p-8 lg:p-10 lg:col-span-5">
                  <div>
                    <div className="mb-3 sm:mb-4 flex items-center gap-3 sm:gap-4 text-xs text-slate">
                      <span className="flex items-center gap-1.5">
                        <Calendar className="h-3.5 w-3.5 text-gold" />
                        {featuredPost.date}
                      </span>
                      <span className="flex items-center gap-1.5">
                        <Clock className="h-3.5 w-3.5 text-gold" />
                        {featuredPost.readTime}
                      </span>
                    </div>
                    <h2 className="font-display text-xl sm:text-2xl lg:text-3xl font-bold leading-snug text-cream">
                      {featuredPost.title}
                    </h2>
                    <p className="mt-3 sm:mt-4 text-xs sm:text-sm md:text-base leading-relaxed text-slate">
                      {featuredPost.excerpt}
                    </p>
                  </div>
                  <div className="mt-6 sm:mt-8 flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-t border-white/10 pt-5 sm:pt-6">
                    <span className="text-xs text-slate">{featuredPost.author.name}</span>
                    <Link
                      to="/blog/$slug"
                      params={{ slug: featuredPost.slug }}
                      className="inline-flex w-full sm:w-auto items-center justify-center gap-2 rounded-lg bg-gold px-4 sm:px-5 py-2 sm:py-2.5 text-xs sm:text-sm font-semibold text-navy transition-all hover:bg-gold-light"
                    >
                      Ler artigo completo
                      <ArrowRight className="h-4 w-4" />
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          </section>
        )}

        {/* Posts Grid */}
        <section className="py-8 sm:py-12 lg:py-16">
          <div className="mx-auto max-w-7xl px-4">
            <div className="mb-6 sm:mb-8 flex items-center justify-between">
              <h2 className="font-display text-xl sm:text-2xl font-bold text-cream">
                {selectedCategory === "Todos" ? "Todos os Artigos" : `Artigos em ${selectedCategory}`}
              </h2>
              <span className="text-xs text-slate">
                {filteredPosts.length} artigo{filteredPosts.length === 1 ? "" : "s"} encontrado{filteredPosts.length === 1 ? "" : "s"}
              </span>
            </div>

            {filteredPosts.length === 0 ? (
              <div className="rounded-2xl border border-white/10 bg-navy-light p-8 sm:p-12 text-center">
                <p className="text-base sm:text-lg text-slate">
                  Nenhum artigo encontrado para a busca "{searchQuery}".
                </p>
                <button
                  onClick={() => {
                    setSelectedCategory("Todos");
                    setSearchQuery("");
                  }}
                  className="mt-4 inline-flex items-center gap-2 text-sm font-semibold text-gold hover:underline"
                >
                  Limpar filtros
                </button>
              </div>
            ) : (
              <div className="grid gap-5 sm:gap-6 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
                {filteredPosts.map((post) => (
                  <article
                    key={post.id}
                    className="group flex flex-col justify-between overflow-hidden rounded-2xl border border-white/10 bg-navy-light transition-all duration-300 hover:-translate-y-1.5 hover:border-gold/40 hover:shadow-2xl hover:shadow-gold/10"
                  >
                    <div>
                      <div className="relative h-44 sm:h-52 overflow-hidden">
                        <img
                          src={post.image}
                          alt={post.title}
                          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                          loading="lazy"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-navy-light/90 to-transparent" />
                        <span className="absolute left-3.5 top-3.5 sm:left-4 sm:top-4 rounded-full bg-gold px-2.5 py-0.5 sm:px-3 sm:py-1 text-xs font-semibold text-navy">
                          {post.category}
                        </span>
                      </div>
                      <div className="p-5 sm:p-6">
                        <div className="mb-2.5 sm:mb-3 flex items-center gap-3 text-xs text-slate">
                          <span className="flex items-center gap-1">
                            <Calendar className="h-3.5 w-3.5 text-gold" />
                            {post.date}
                          </span>
                          <span className="flex items-center gap-1">
                            <Clock className="h-3.5 w-3.5 text-gold" />
                            {post.readTime}
                          </span>
                        </div>
                        <h3 className="font-display text-lg sm:text-xl font-bold leading-snug text-cream transition-colors group-hover:text-gold">
                          {post.title}
                        </h3>
                        <p className="mt-2.5 line-clamp-3 text-xs sm:text-sm leading-relaxed text-slate">
                          {post.excerpt}
                        </p>
                      </div>
                    </div>

                    <div className="border-t border-white/5 p-5 pt-3.5 sm:p-6 sm:pt-4">
                      <Link
                        to="/blog/$slug"
                        params={{ slug: post.slug }}
                        className="inline-flex items-center gap-2 text-xs sm:text-sm font-semibold text-gold transition-colors hover:text-gold-light"
                      >
                        Ler artigo completo
                        <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                      </Link>
                    </div>
                  </article>
                ))}
              </div>
            )}
          </div>
        </section>

        {/* CTA Section */}
        <section className="border-t border-white/10 bg-gradient-to-r from-navy via-navy-light to-navy py-12 sm:py-16">
          <div className="mx-auto max-w-5xl px-4 text-center">
            <h3 className="font-display text-2xl sm:text-3xl md:text-4xl font-bold text-cream">
              Ficou com alguma dúvida sobre o seu seguro?
            </h3>
            <p className="mt-3 sm:mt-4 text-sm sm:text-base md:text-lg text-slate">
              Nossa equipe de especialistas está pronta para orientar você com as melhores cotações do mercado.
            </p>
            <a
              href="/#contato"
              className="mt-6 sm:mt-8 inline-flex w-full sm:w-auto items-center justify-center gap-2 rounded-lg bg-gold px-6 sm:px-8 py-3.5 sm:py-4 text-sm sm:text-base font-semibold text-navy shadow-lg shadow-gold/20 transition-all hover:bg-gold-light"
            >
              Solicitar Cotação Personalizada
              <ChevronRight className="h-5 w-5" />
            </a>
          </div>
        </section>
      </main>

      <Footer onPrivacy={() => setPrivacyOpen(true)} onTerms={() => setTermsOpen(true)} />
      <PrivacyModal open={privacyOpen} onClose={() => setPrivacyOpen(false)} />
      <TermsModal open={termsOpen} onClose={() => setTermsOpen(false)} />
    </div>
  );
}

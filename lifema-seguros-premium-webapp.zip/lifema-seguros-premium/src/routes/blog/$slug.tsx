import { useState } from "react";
import { createFileRoute, Link, useParams } from "@tanstack/react-router";
import { Header } from "../../components/Header";
import { Footer } from "../../components/Footer";
import { PrivacyModal } from "../../components/PrivacyModal";
import { TermsModal } from "../../components/TermsModal";
import { blogPosts } from "../../data/blogPosts";
import { Calendar, Clock, ArrowLeft, ArrowRight, Share2, CheckCircle2, ChevronRight, User } from "lucide-react";

export const Route = createFileRoute("/blog/$slug")({
  component: BlogPostPage,
  head: ({ params }) => {
    const post = blogPosts.find((p) => p.slug === params.slug);
    if (!post) {
      return {
        meta: [{ title: "Artigo não encontrado | Lifema Seguros" }],
      };
    }
    return {
      meta: [
        { title: `${post.title} | Blog Lifema Seguros` },
        { name: "description", content: post.excerpt },
        { property: "og:title", content: post.title },
        { property: "og:description", content: post.excerpt },
        { property: "og:type", content: "article" },
      ],
    };
  },
});

function BlogPostPage() {
  const { slug } = useParams({ from: "/blog/$slug" });
  const [privacyOpen, setPrivacyOpen] = useState(false);
  const [termsOpen, setTermsOpen] = useState(false);
  const [copied, setCopied] = useState(false);

  const post = blogPosts.find((p) => p.slug === slug);

  const handleShare = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(window.location.href);
      setCopied(true);
      setTimeout(() => setCopied(false), 3000);
    }
  };

  if (!post) {
    return (
      <div className="flex min-h-screen flex-col justify-between bg-navy text-cream">
        <Header />
        <main className="flex flex-1 items-center justify-center px-4 py-32 text-center">
          <div className="max-w-md">
            <h1 className="font-display text-3xl font-bold text-cream sm:text-4xl">
              Artigo não encontrado
            </h1>
            <p className="mt-4 text-slate">
              O post que você está procurando não existe ou foi removido.
            </p>
            <div className="mt-8">
              <Link
                to="/blog"
                className="inline-flex items-center gap-2 rounded-lg bg-gold px-6 py-3 text-sm font-semibold text-navy transition-all hover:bg-gold-light"
              >
                <ArrowLeft className="h-4 w-4" />
                Voltar para o Blog
              </Link>
            </div>
          </div>
        </main>
        <Footer onPrivacy={() => setPrivacyOpen(true)} onTerms={() => setTermsOpen(true)} />
      </div>
    );
  }

  const relatedPosts = blogPosts
    .filter((p) => p.slug !== post.slug)
    .slice(0, 3);

  return (
    <div className="min-h-screen bg-navy text-cream">
      <Header />

      <main className="pt-24 sm:pt-32">
        {/* Breadcrumb Navigation */}
        <div className="mx-auto max-w-4xl px-4 py-3 sm:py-4">
          <nav className="flex items-center gap-1.5 sm:gap-2 text-xs text-slate sm:text-sm">
            <Link to="/" className="hover:text-gold transition-colors shrink-0">
              Início
            </Link>
            <ChevronRight className="h-3.5 w-3.5 text-slate/50 shrink-0" />
            <Link to="/blog" className="hover:text-gold transition-colors shrink-0">
              Blog
            </Link>
            <ChevronRight className="h-3.5 w-3.5 text-slate/50 shrink-0" />
            <span className="truncate text-gold">{post.title}</span>
          </nav>
        </div>

        {/* Post Header */}
        <article className="mx-auto max-w-4xl px-4 py-4 sm:py-8">
          <header className="mb-8 sm:mb-10">
            <div className="mb-3 sm:mb-4 flex flex-wrap items-center gap-2.5 sm:gap-3">
              <span className="rounded-full bg-gold px-3 py-0.5 sm:px-3.5 sm:py-1 text-xs font-bold text-navy">
                {post.category}
              </span>
              <span className="flex items-center gap-1.5 text-xs text-slate">
                <Calendar className="h-3.5 w-3.5 text-gold" />
                {post.date}
              </span>
              <span className="flex items-center gap-1.5 text-xs text-slate">
                <Clock className="h-3.5 w-3.5 text-gold" />
                {post.readTime}
              </span>
            </div>

            <h1 className="font-display text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-extrabold leading-tight text-cream text-balance">
              {post.title}
            </h1>

            <p className="mt-4 sm:mt-6 text-base sm:text-lg md:text-xl leading-relaxed text-slate">
              {post.excerpt}
            </p>

            {/* Author info & Share button */}
            <div className="mt-6 sm:mt-8 flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-y border-white/10 py-3.5 sm:py-4">
              <div className="flex items-center gap-3">
                <div className="grid h-9 w-9 sm:h-10 sm:w-10 place-items-center rounded-full bg-gold/10 text-gold border border-gold/20">
                  <User className="h-4 w-4 sm:h-5 sm:w-5" />
                </div>
                <div>
                  <div className="text-xs sm:text-sm font-semibold text-cream">{post.author.name}</div>
                  <div className="text-[11px] sm:text-xs text-slate">{post.author.role}</div>
                </div>
              </div>

              <button
                onClick={handleShare}
                className="inline-flex w-full sm:w-auto items-center justify-center gap-2 rounded-lg border border-white/10 bg-navy-light px-3.5 sm:px-4 py-2 text-xs font-medium text-cream transition-colors hover:border-gold/40 hover:text-gold"
              >
                <Share2 className="h-3.5 w-3.5" />
                {copied ? "Link copiado!" : "Compartilhar"}
              </button>
            </div>
          </header>

          {/* Cover Image */}
          <div className="mb-8 sm:mb-12 overflow-hidden rounded-2xl sm:rounded-3xl border border-white/10 bg-navy-light shadow-2xl">
            <img
              src={post.image}
              alt={post.title}
              className="h-auto w-full object-cover max-h-[480px]"
            />
          </div>

          {/* Article Body Content */}
          <div className="prose prose-invert max-w-none space-y-6 sm:space-y-8 text-sm sm:text-base md:text-lg leading-relaxed text-slate">
            <p className="text-base sm:text-lg md:text-xl font-medium text-cream/90 leading-relaxed border-l-2 border-gold pl-3.5 sm:pl-4 py-1 bg-gold/5 rounded-r-lg">
              {post.content.intro}
            </p>

            {post.content.sections.map((sec, i) => (
              <div key={i} className="space-y-3 sm:space-y-4 pt-3 sm:pt-4">
                <h2 className="font-display text-xl sm:text-2xl md:text-3xl font-bold text-cream">
                  {sec.title}
                </h2>
                <p className="text-slate leading-relaxed">{sec.text}</p>
                {sec.bullets && (
                  <ul className="space-y-2 pt-2">
                    {sec.bullets.map((bullet, idx) => (
                      <li key={idx} className="flex items-start gap-2.5 sm:gap-3 text-xs sm:text-base text-cream/90">
                        <CheckCircle2 className="mt-1 h-3.5 w-3.5 sm:h-4 sm:w-4 shrink-0 text-gold" />
                        <span>{bullet}</span>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            ))}

            {/* In-article CTA box */}
            <div className="my-8 sm:my-10 rounded-2xl border border-gold/30 bg-gradient-to-r from-navy-light to-navy p-5 sm:p-8 shadow-xl">
              <h3 className="font-display text-lg sm:text-xl md:text-2xl font-bold text-cream">
                Quer cotar este seguro sem compromisso?
              </h3>
              <p className="mt-2 text-xs sm:text-sm md:text-base text-slate">
                Fale com nossos corretores na Lifema Seguros e encontre a cobertura perfeita com o melhor preço.
              </p>
              <a
                href="/#contato"
                className="mt-5 sm:mt-6 inline-flex w-full sm:w-auto items-center justify-center gap-2 rounded-lg bg-gold px-5 sm:px-6 py-2.5 sm:py-3 text-xs sm:text-sm font-semibold text-navy transition-all hover:bg-gold-light"
              >
                Solicitar Cotação Agora
                <ChevronRight className="h-4 w-4" />
              </a>
            </div>

            <div className="pt-3 sm:pt-4">
              <p className="text-slate leading-relaxed">{post.content.conclusion}</p>
            </div>
          </div>

          {/* Post Footer / Navigation */}
          <div className="mt-12 sm:mt-16 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 border-t border-white/10 pt-6 sm:pt-8">
            <Link
              to="/blog"
              className="inline-flex items-center justify-center gap-2 rounded-lg border border-white/10 bg-navy-light px-4 sm:px-5 py-2 sm:py-2.5 text-xs sm:text-sm font-semibold text-cream transition-colors hover:border-gold/40 hover:text-gold"
            >
              <ArrowLeft className="h-4 w-4" />
              Voltar ao Blog
            </Link>

            <a
              href="/#contato"
              className="inline-flex items-center justify-center gap-2 text-xs sm:text-sm font-semibold text-gold hover:underline"
            >
              Falar com corretor
              <ArrowRight className="h-4 w-4" />
            </a>
          </div>
        </article>

        {/* Related Posts */}
        {relatedPosts.length > 0 && (
          <section className="border-t border-white/10 bg-navy-light/30 py-12 sm:py-16">
            <div className="mx-auto max-w-7xl px-4">
              <div className="mb-6 sm:mb-10 flex items-center justify-between">
                <h2 className="font-display text-xl sm:text-2xl md:text-3xl font-bold text-cream">
                  Artigos Relacionados
                </h2>
                <Link
                  to="/blog"
                  className="inline-flex items-center gap-1.5 text-xs sm:text-sm font-semibold text-gold hover:underline"
                >
                  Ver todos
                  <ChevronRight className="h-4 w-4" />
                </Link>
              </div>

              <div className="grid gap-5 sm:gap-6 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
                {relatedPosts.map((rel) => (
                  <article
                    key={rel.id}
                    className="group flex flex-col justify-between overflow-hidden rounded-2xl border border-white/10 bg-navy-light transition-all duration-300 hover:-translate-y-1 hover:border-gold/40 hover:shadow-xl"
                  >
                    <div>
                      <div className="relative h-44 overflow-hidden">
                        <img
                          src={rel.image}
                          alt={rel.title}
                          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                          loading="lazy"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-navy-light/80 to-transparent" />
                        <span className="absolute left-4 top-4 rounded-full bg-gold px-3 py-0.5 text-xs font-semibold text-navy">
                          {rel.category}
                        </span>
                      </div>
                      <div className="p-5">
                        <div className="mb-2 text-xs text-slate">{rel.date}</div>
                        <h3 className="font-display text-base font-bold leading-snug text-cream group-hover:text-gold transition-colors">
                          {rel.title}
                        </h3>
                      </div>
                    </div>

                    <div className="p-5 pt-0">
                      <Link
                        to="/blog/$slug"
                        params={{ slug: rel.slug }}
                        className="inline-flex items-center gap-1.5 text-xs font-semibold text-gold hover:text-gold-light"
                      >
                        Ler artigo
                        <ArrowRight className="h-3.5 w-3.5" />
                      </Link>
                    </div>
                  </article>
                ))}
              </div>
            </div>
          </section>
        )}
      </main>

      <Footer onPrivacy={() => setPrivacyOpen(true)} onTerms={() => setTermsOpen(true)} />
      <PrivacyModal open={privacyOpen} onClose={() => setPrivacyOpen(false)} />
      <TermsModal open={termsOpen} onClose={() => setTermsOpen(false)} />
    </div>
  );
}

import { useReveal } from "../hooks/useReveal";
import { cn } from "../lib/utils";
import { UserCheck, SlidersHorizontal, GitCompare, Headphones } from "lucide-react";

const benefits = [
  {
    icon: UserCheck,
    title: "Atendimento Personalizado",
    description: "Entendemos seu perfil e suas necessidades antes de sugerir qualquer solução.",
  },
  {
    icon: SlidersHorizontal,
    title: "Soluções Sob Medida",
    description: "Buscamos alternativas adequadas para cada cliente, sem soluções genéricas.",
  },
  {
    icon: GitCompare,
    title: "Diversas Opções",
    description: "Compare possibilidades entre diferentes seguradoras antes de tomar sua decisão.",
  },
  {
    icon: Headphones,
    title: "Acompanhamento",
    description: "Suporte durante toda a sua jornada com o seguro, desde a cotação até a renovação.",
  },
];

export function Benefits() {
  const { ref, visible } = useReveal<HTMLElement>();

  return (
    <section id="beneficios" ref={ref} className="relative overflow-hidden section-padding">
      <div className="absolute right-0 top-1/2 h-[400px] w-[400px] -translate-y-1/2 translate-x-1/2 rounded-full bg-gold/5 blur-[100px]" />

      <div className="relative mx-auto max-w-7xl px-4">
        <div className="grid gap-8 md:gap-12 lg:grid-cols-2 lg:gap-16 xl:gap-20 items-center">
          <div className={cn("reveal", visible && "reveal-visible")}>
            <span className="mb-2 sm:mb-3 inline-block text-xs sm:text-sm font-semibold uppercase tracking-wider text-gold">
              Diferenciais
            </span>
            <h2 className="font-display text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold leading-tight text-cream text-balance">
              Por que escolher a <span className="text-gold">Lifema</span>?
            </h2>
            <p className="mt-4 sm:mt-6 text-base sm:text-lg leading-relaxed text-slate">
              Nossa prioridade é oferecer clareza, transparência e opções reais para que você se
              sinta seguro em cada decisão.
            </p>
          </div>

          <div className="grid gap-4 sm:gap-5 grid-cols-1 sm:grid-cols-2">
            {benefits.map((item, i) => (
              <div
                key={item.title}
                className={cn(
                  "rounded-2xl border border-white/10 bg-navy-light p-5 sm:p-6 transition-all duration-300 hover:-translate-y-1 hover:border-gold/30 hover:shadow-xl hover:shadow-gold/5 reveal",
                  visible && "reveal-visible"
                )}
                style={{ transitionDelay: `${i * 100}ms` }}
              >
                <div className="mb-3 sm:mb-4 flex h-11 w-11 sm:h-12 sm:w-12 items-center justify-center rounded-lg bg-gold/10 text-gold">
                  <item.icon className="h-5 w-5 sm:h-6 sm:w-6" />
                </div>
                <h3 className="font-display text-base sm:text-lg font-bold text-cream">{item.title}</h3>
                <p className="mt-2 text-xs sm:text-sm leading-relaxed text-slate">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

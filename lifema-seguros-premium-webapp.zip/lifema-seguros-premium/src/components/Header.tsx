import { useEffect, useState } from "react";
import { Menu, X, Phone, Mail, MapPin } from "lucide-react";
import { cn } from "../lib/utils";
import logoImg from "../assets/lifema-logo.png";
import { COMPANY } from "../data/company";

const navItems = [
  { label: "Início", href: "/#inicio" },
  { label: "Sobre Nós", href: "/#sobre" },
  { label: "Seguros", href: "/#seguros" },
  { label: "Benefícios", href: "/#beneficios" },
  { label: "Blog", href: "/blog" },
  { label: "Contato", href: "/#contato" },
];

export function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [activeSection, setActiveSection] = useState("inicio");

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    if (typeof window === "undefined" || window.location.pathname !== "/") return;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setActiveSection(entry.target.id);
          }
        });
      },
      { rootMargin: "-40% 0px -50% 0px", threshold: 0.1 }
    );

    navItems.forEach(({ href }) => {
      if (!href.includes("#")) return;
      const id = href.split("#")[1];
      const el = document.getElementById(id);
      if (el) observer.observe(el);
    });

    return () => observer.disconnect();
  }, []);

  const handleAnchorClick = (href: string) => {
    setMobileOpen(false);
    if (href === "/blog") {
      window.location.href = "/blog";
      return;
    }
    const hash = href.includes("#") ? href.split("#")[1] : "";
    if (window.location.pathname !== "/") {
      window.location.href = `/#${hash}`;
      return;
    }
    const el = document.getElementById(hash);
    if (el) {
      const headerOffset = 88;
      const top = el.getBoundingClientRect().top + window.scrollY - headerOffset;
      window.scrollTo({ top, behavior: "smooth" });
    }
  };

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-50 w-full transition-all duration-300",
        scrolled || mobileOpen
          ? "bg-navy/95 shadow-lg shadow-black/20 backdrop-blur-md"
          : "bg-gradient-to-b from-navy/90 to-transparent"
      )}
    >
      {/* top bar */}
      <div className="hidden border-b border-white/5 bg-navy-light/60 md:block">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-1.5 text-xs text-slate">
          <div className="flex flex-wrap items-center gap-4 lg:gap-6">
            <a
              href={COMPANY.mapsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 transition-colors hover:text-gold"
            >
              <MapPin className="h-3.5 w-3.5 shrink-0 text-gold" />
              <span className="truncate max-w-[280px] lg:max-w-none">{COMPANY.address}</span>
            </a>
            <a
              href={`tel:${COMPANY.phoneRaw}`}
              className="flex items-center gap-1.5 transition-colors hover:text-gold"
            >
              <Phone className="h-3.5 w-3.5 shrink-0 text-gold" />
              <span>{COMPANY.phone}</span>
            </a>
            <a
              href={`mailto:${COMPANY.email}`}
              className="flex items-center gap-1.5 transition-colors hover:text-gold"
            >
              <Mail className="h-3.5 w-3.5 shrink-0 text-gold" />
              <span className="hidden xl:inline">{COMPANY.email}</span>
              <span className="xl:hidden">E-mail</span>
            </a>
          </div>
          <div className="flex items-center gap-4">
            <a
              href={COMPANY.social.instagram}
              target="_blank"
              rel="noopener noreferrer"
              className="transition-colors hover:text-gold"
            >
              Instagram
            </a>
            <a
              href={COMPANY.social.facebook}
              target="_blank"
              rel="noopener noreferrer"
              className="transition-colors hover:text-gold"
            >
              Facebook
            </a>
          </div>
        </div>
      </div>

      {/* main nav */}
      <div className="mx-auto flex w-full max-w-7xl items-center justify-between px-4 py-3 sm:py-4">
        <a
          href="/"
          onClick={(e) => {
            if (window.location.pathname === "/") {
              e.preventDefault();
              handleAnchorClick("/#inicio");
            }
          }}
          className="flex items-center gap-2.5 sm:gap-3 shrink-0"
        >
          <img
            src={logoImg}
            alt={COMPANY.name}
            className="h-8 sm:h-10 lg:h-12 w-auto object-contain"
          />
          <span className="font-display text-sm font-bold text-cream sm:text-base lg:text-lg">
            {COMPANY.name}
          </span>
        </a>

        {/* desktop menu */}
        <nav className="hidden items-center gap-0.5 lg:flex xl:gap-1.5">
          {navItems.map((item) => (
            <a
              key={item.href}
              href={item.href}
              onClick={(e) => {
                e.preventDefault();
                handleAnchorClick(item.href);
              }}
              className={cn(
                "relative px-2.5 py-2 text-xs font-medium transition-colors xl:px-4 xl:text-sm",
                activeSection === item.href.replace("#", "")
                  ? "text-gold"
                  : "text-cream/80 hover:text-cream"
              )}
            >
              {item.label}
              {activeSection === item.href.replace("#", "") && (
                <span className="absolute bottom-0 left-1/2 h-0.5 w-5 -translate-x-1/2 rounded-full bg-gold" />
              )}
            </a>
          ))}
        </nav>

        <div className="hidden items-center gap-4 lg:flex">
          <a
            href="/#contato"
            onClick={(e) => {
              e.preventDefault();
              handleAnchorClick("/#contato");
            }}
            className="inline-flex items-center justify-center rounded-lg bg-gold px-4 py-2 text-xs font-semibold text-navy shadow-md shadow-gold/20 transition-all hover:bg-gold-light hover:shadow-gold/40 xl:px-5 xl:py-2.5 xl:text-sm"
          >
            Solicitar Cotação
          </a>
        </div>

        {/* mobile toggle */}
        <button
          type="button"
          className="inline-flex items-center justify-center rounded-lg p-2 text-cream lg:hidden focus:outline-none shrink-0"
          onClick={() => setMobileOpen(!mobileOpen)}
          aria-label={mobileOpen ? "Fechar menu" : "Abrir menu"}
        >
          {mobileOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </div>

      {/* backdrop when open */}
      {mobileOpen && (
        <div
          className="fixed inset-0 top-[56px] sm:top-[68px] z-30 bg-black/60 backdrop-blur-sm lg:hidden"
          onClick={() => setMobileOpen(false)}
        />
      )}

      {/* mobile drawer */}
      <div
        className={cn(
          "absolute inset-x-0 top-full z-40 max-h-[calc(100dvh-4.5rem)] overflow-y-auto border-t border-white/10 bg-navy-light/98 shadow-2xl transition-all duration-300 lg:hidden",
          mobileOpen
            ? "pointer-events-auto opacity-100 translate-y-0 visible"
            : "pointer-events-none opacity-0 -translate-y-2 invisible"
        )}
      >
        <nav className="flex flex-col px-4 py-4 space-y-1">
          {navItems.map((item) => (
            <a
              key={item.href}
              href={item.href}
              onClick={(e) => {
                e.preventDefault();
                handleAnchorClick(item.href);
              }}
              className={cn(
                "flex items-center min-h-[44px] rounded-lg px-3 py-2 text-base font-medium transition-colors border-b border-white/5",
                activeSection === item.href.replace("#", "")
                  ? "text-gold bg-white/5"
                  : "text-cream/80 hover:text-cream hover:bg-white/5"
              )}
            >
              {item.label}
            </a>
          ))}
          <div className="pt-2">
            <a
              href="/#contato"
              onClick={(e) => {
                e.preventDefault();
                handleAnchorClick("/#contato");
              }}
              className="inline-flex min-h-[44px] w-full items-center justify-center rounded-lg bg-gold px-4 py-3 text-sm font-semibold text-navy shadow-md shadow-gold/20"
            >
              Solicitar Cotação
            </a>
          </div>
        </nav>
      </div>
    </header>
  );
}

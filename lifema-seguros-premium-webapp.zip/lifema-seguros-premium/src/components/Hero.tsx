import { useEffect, useRef, useState } from "react";
import { Shield, Heart, Handshake, ChevronRight } from "lucide-react";
import { cn } from "../lib/utils";
import heroImg from "../assets/hero.jpg";

const highlights = [
  { icon: Handshake, label: "Atendimento Personalizado" },
  { icon: Shield, label: "Soluções Sob Medida" },
  { icon: Heart, label: "Proteção para diferentes momentos" },
];

export function Hero() {
  const [offset, setOffset] = useState(0);
  const rafRef = useRef<number | undefined>(undefined);


  useEffect(() => {
    const onScroll = () => {
      if (rafRef.current) return;
      rafRef.current = requestAnimationFrame(() => {
        setOffset(window.scrollY * 0.25);
        rafRef.current = undefined;
      });
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const handleAnchor = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      const top = el.getBoundingClientRect().top + window.scrollY - 88;
      window.scrollTo({ top, behavior: "smooth" });
    }
  };

  return (
    <section
      id="inicio"
      className="relative min-h-[85vh] lg:min-h-screen overflow-hidden pt-24 sm:pt-28 md:pt-32"
    >
      {/* background image with parallax */}
      <div
        className="absolute inset-0 scale-110"
        style={{ transform: `translateY(${offset}px) scale(1.1)` }}
      >
        <img
          src={heroImg}
          alt="Família protegida em frente à casa"
          className="h-full w-full object-cover"
          width={1920}
          height={1080}
          fetchPriority="high"
        />
      </div>

      {/* overlay gradient */}
      <div className="absolute inset-0 bg-gradient-to-r from-navy via-navy/90 to-navy/70" />
      <div className="absolute inset-0 bg-gradient-to-t from-navy via-transparent to-navy/40" />

      {/* subtle gold accent */}
      <div className="absolute -right-40 top-1/4 h-[500px] w-[500px] rounded-full bg-gold/10 blur-[120px]" />

      <div className="relative mx-auto flex max-w-7xl min-h-[calc(100vh-6rem)] lg:min-h-[calc(100vh-7rem)] flex-col justify-center px-4 py-12 sm:py-16 md:py-20 lg:py-24">
        <div className="max-w-3xl">
          <span className="mb-3 sm:mb-4 inline-flex items-center gap-2 rounded-full border border-gold/30 bg-gold/10 px-3.5 py-1 sm:px-4 sm:py-1.5 text-xs sm:text-sm font-medium text-gold">
            <span className="h-1.5 w-1.5 rounded-full bg-gold" />
            Corretora de Seguros
          </span>

          <h1 className="font-display text-3xl font-extrabold leading-[1.15] text-cream sm:text-4xl md:text-5xl lg:text-6xl xl:text-7xl text-balance">
            Proteção para o que{" "}
            <span className="text-gold">realmente importa</span>.
          </h1>

          <p className="mt-4 sm:mt-6 max-w-2xl text-base sm:text-lg md:text-xl leading-relaxed text-slate">
            Na Lifema Seguros, encontramos soluções para proteger seu patrimônio, sua
            família, seu veículo e sua empresa com a orientação que você precisa.
          </p>

          <div className="mt-6 sm:mt-8 flex flex-col sm:flex-row items-stretch sm:items-center gap-3 sm:gap-4">
            <button
              onClick={() => handleAnchor("contato")}
              className="group inline-flex w-full sm:w-auto items-center justify-center gap-2 rounded-lg bg-gold px-6 sm:px-7 py-3 sm:py-3.5 text-sm sm:text-base font-semibold text-navy shadow-lg shadow-gold/25 transition-all hover:bg-gold-light hover:shadow-gold/40"
            >
              Solicitar Cotação
              <ChevronRight className="h-5 w-5 transition-transform group-hover:translate-x-1" />
            </button>
            <button
              onClick={() => handleAnchor("seguros")}
              className="inline-flex w-full sm:w-auto items-center justify-center rounded-lg border border-cream/20 bg-cream/5 px-6 sm:px-7 py-3 sm:py-3.5 text-sm sm:text-base font-semibold text-cream backdrop-blur-sm transition-colors hover:bg-cream/10"
            >
              Conheça nossos Seguros
            </button>
          </div>
        </div>

        {/* highlights cards */}
        <div className="mt-10 sm:mt-12 md:mt-16 grid gap-3 sm:gap-4 grid-cols-1 sm:grid-cols-3 lg:max-w-4xl">
          {highlights.map((item, i) => (
            <div
              key={item.label}
              className={cn(
                "flex items-center gap-3.5 sm:gap-4 rounded-xl border border-white/10 bg-navy-light/60 p-3.5 sm:p-4 lg:p-5 backdrop-blur-md transition-all hover:border-gold/30 hover:bg-navy-light",
                i === 0 && "animate-fade-in"
              )}
              style={{ animationDelay: `${i * 120}ms` }}
            >
              <div className="grid h-10 w-10 sm:h-11 sm:w-11 shrink-0 place-items-center rounded-lg bg-gold/10 text-gold">
                <item.icon className="h-5 w-5" />
              </div>
              <span className="text-xs sm:text-sm lg:text-base font-semibold text-cream">
                {item.label}
              </span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

import { ChevronRight, Phone } from "lucide-react";

export function CtaBand() {
  const handleAnchor = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      const top = el.getBoundingClientRect().top + window.scrollY - 88;
      window.scrollTo({ top, behavior: "smooth" });
    }
  };

  return (
    <section className="relative overflow-hidden bg-gradient-to-r from-navy via-navy-light to-navy py-12 sm:py-16 md:py-20">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,_var(--tw-gradient-stops))] from-gold/10 to-transparent" />

      <div className="relative mx-auto flex max-w-7xl flex-col items-center justify-between gap-6 px-4 sm:flex-row">
        <div className="text-center sm:text-left">
          <span className="mb-2 inline-flex items-center gap-2 text-xs sm:text-sm font-semibold text-gold">
            <Phone className="h-4 w-4" />
            Fale com um corretor
          </span>
          <h2 className="font-display text-2xl sm:text-3xl lg:text-4xl font-bold text-cream text-balance">
            Proteja hoje o que importa amanhã.
          </h2>
        </div>
        <button
          onClick={() => handleAnchor("contato")}
          className="group inline-flex w-full sm:w-auto items-center justify-center gap-2 rounded-lg bg-gold px-6 sm:px-7 py-3 sm:py-3.5 text-sm sm:text-base font-semibold text-navy shadow-lg shadow-gold/25 transition-all hover:bg-gold-light hover:shadow-gold/40 shrink-0"
        >
          Solicitar Cotação
          <ChevronRight className="h-5 w-5 transition-transform group-hover:translate-x-1" />
        </button>
      </div>
    </section>
  );
}

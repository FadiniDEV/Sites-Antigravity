import { useReveal } from "../hooks/useReveal";
import { cn } from "../lib/utils";
import { InsuranceCard } from "./InsuranceCard";
import {
  Car,
  Home,
  HeartPulse,
  Building2,
  Stethoscope,
  Plane,
  Bike,
  Truck,
  Users,
} from "lucide-react";

const insurances = [
  {
    icon: Car,
    title: "Seguro Auto",
    description: "Proteção completa para carros, com coberturas que se adaptam ao seu perfil.",
    slug: "como-escolher-um-seguro-auto-ideal-para-o-seu-perfil",
  },
  {
    icon: Home,
    title: "Seguro Residencial",
    description: "Cobertura para sua casa e bens contra roubo, incêndio, danos e responsabilidade civil.",
    slug: "seguro-residencial-o-que-cobre-e-como-contratar",
  },
  {
    icon: HeartPulse,
    title: "Seguro de Vida",
    description: "Tranquilidade para você e segurança financeira para quem você ama.",
    slug: "seguro-de-vida-quando-e-por-que-fazer",
  },
  {
    icon: Building2,
    title: "Seguro Empresarial",
    description: "Soluções para proteger seu negócio, patrimônio e operação.",
    slug: "seguro-empresarial-proteja-seu-negocio-desde-o-inicio",
  },
  {
    icon: Stethoscope,
    title: "Seguro Saúde",
    description: "Planos de saúde individual, familiar ou empresarial com as melhores opções.",
    slug: "seguro-saude-como-escolher-o-melhor-plano-para-voce-e-sua-empresa",
  },
  {
    icon: Plane,
    title: "Seguro Viagem",
    description: "Viaje com segurança, com cobertura médica, bagagem e assistência 24h.",
    slug: "seguro-viagem-por-que-e-indispensavel-nas-suas-ferias-ou-trabalho",
  },
  {
    icon: Bike,
    title: "Seguro Moto",
    description: "Proteção para motocicletas, com coberturas para roubo, furto e acidentes.",
    slug: "seguro-moto-tudo-o-que-voce-precisa-saber-para-proteger-sua-motocicleta",
  },
  {
    icon: Truck,
    title: "Seguro Caminhão",
    description: "Cobertura especializada para veículos de carga e transporte.",
    slug: "seguro-caminhao-protecao-completa-para-veiculos-pesados-e-cargas",
  },
  {
    icon: Users,
    title: "Seguro para Frotas",
    description: "Gestão de risco e proteção para frotas de veículos empresariais.",
    slug: "seguro-para-frotas-como-reduzir-custos-e-proteger-os-veiculos-da-empresa",
  },
];

export function InsuranceGrid() {
  const { ref, visible } = useReveal<HTMLElement>();

  return (
    <section id="seguros" ref={ref} className="relative section-padding bg-navy-light/30">
      <div className="mx-auto max-w-7xl px-4">
        <div
          className={cn(
            "mx-auto max-w-3xl text-center reveal",
            visible && "reveal-visible"
          )}
        >
          <span className="mb-2 sm:mb-3 inline-block text-xs sm:text-sm font-semibold uppercase tracking-wider text-gold">
            Nossos Seguros
          </span>
          <h2 className="font-display text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold leading-tight text-cream text-balance">
            Proteção para cada necessidade
          </h2>
          <p className="mt-3 sm:mt-4 text-sm sm:text-base md:text-lg text-slate">
            Escolha a cobertura ideal e conte com nossa orientação para encontrar a melhor
            alternativa.
          </p>
        </div>

        <div className="mt-8 sm:mt-10 md:mt-14 grid gap-4 sm:gap-5 lg:gap-6 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
          {insurances.map((item, i) => (
            <div
              key={item.title}
              className={cn(
                "reveal",
                visible && "reveal-visible"
              )}
              style={{ transitionDelay: `${i * 80}ms` }}
            >
              <InsuranceCard {...item} />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

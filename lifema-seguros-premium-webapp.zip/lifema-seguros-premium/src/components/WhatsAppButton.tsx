import { MessageCircle } from "lucide-react";
import { useState } from "react";
import { COMPANY } from "../data/company";

export function WhatsAppButton() {
  const [tooltipVisible, setTooltipVisible] = useState(false);

  const href = `https://wa.me/${COMPANY.whatsappNumber}?text=${encodeURIComponent(
    COMPANY.whatsappDefaultMessage
  )}`;

  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Fale conosco pelo WhatsApp"
      className="fixed bottom-4 right-4 z-50 flex items-center gap-2.5 sm:gap-3 rounded-full bg-gold p-3.5 sm:p-4 text-navy shadow-lg shadow-gold/25 transition-transform duration-300 hover:scale-110 hover:shadow-gold/40 sm:bottom-6 sm:right-6"
      onMouseEnter={() => setTooltipVisible(true)}
      onMouseLeave={() => setTooltipVisible(false)}
      onFocus={() => setTooltipVisible(true)}
      onBlur={() => setTooltipVisible(false)}
    >
      <MessageCircle className="h-5 w-5 sm:h-6 sm:w-6 shrink-0 fill-current" />
      <span
        className={`hidden max-w-0 overflow-hidden whitespace-nowrap text-xs sm:text-sm font-semibold transition-all duration-300 sm:inline-block ${
          tooltipVisible ? "max-w-[10rem] pl-1" : ""
        }`}
      >
        Fale no WhatsApp
      </span>
    </a>
  );
}

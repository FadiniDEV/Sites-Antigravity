import { useReveal } from "../hooks/useReveal";
import { cn } from "../lib/utils";
import { Quote, Star } from "lucide-react";

const testimonials = [
  {
    name: "Mariana Vasconcelos",
    role: "Seguro Residencial — Campinas / SP",
    text: "Atendimento claro e extremamente atencioso. Me ajudaram a entender cada detalhe da apólice e a escolher a melhor proteção para a nossa casa com ótimo custo-benefício.",
  },
  {
    name: "Carlos Eduardo Mendes",
    role: "Diretor Comercial — Seguro Empresarial",
    text: "A Lifema Seguros nos apresentou opções completas para a nossa empresa e cuidou de toda a burocracia. O suporte e a agilidade deles fazem toda a diferença no dia a dia.",
  },
  {
    name: "Rodrigo Silveira",
    role: "Seguro Auto & Frota",
    text: "Consegui uma cotação justa e com cobertura completa para os veículos. Quando precisei de assistência para guincho, o retorno foi rápido e sem complicações.",
  },
];

export function Testimonials() {
  const { ref, visible } = useReveal<HTMLElement>();

  return (
    <section ref={ref} className="relative overflow-hidden section-padding">
      <div className="absolute -left-40 bottom-0 h-[400px] w-[400px] rounded-full bg-gold/5 blur-[100px]" />

      <div className="relative mx-auto max-w-7xl px-4">
        <div className={cn("mb-10 sm:mb-14 text-center reveal", visible && "reveal-visible")}>
          <span className="mb-2 sm:mb-3 inline-block text-xs sm:text-sm font-semibold uppercase tracking-wider text-gold">
            Depoimentos
          </span>
          <h2 className="font-display text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold leading-tight text-cream text-balance">
            O que dizem sobre nós
          </h2>
          <p className="mt-3 sm:mt-4 text-xs sm:text-sm text-slate">
            A tranquilidade e a confiança de quem conta com a nossa assessoria.
          </p>
        </div>

        <div className="grid gap-5 sm:gap-6 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
          {testimonials.map((item, i) => (
            <div
              key={i}
              className={cn(
                "relative rounded-2xl border border-white/10 bg-navy-light p-5 sm:p-6 lg:p-7 transition-all duration-300 hover:border-gold/30 hover:shadow-xl hover:shadow-gold/5 reveal",
                visible && "reveal-visible"
              )}
              style={{ transitionDelay: `${i * 120}ms` }}
            >
              <Quote className="absolute right-5 top-5 sm:right-6 sm:top-6 h-8 w-8 sm:h-10 sm:w-10 text-gold/10" />
              <div className="mb-3 sm:mb-4 flex gap-1">
                {[...Array(5)].map((_, idx) => (
                  <Star key={idx} className="h-3.5 w-3.5 sm:h-4 sm:w-4 fill-gold text-gold" />
                ))}
              </div>
              <p className="relative z-10 text-sm sm:text-base leading-relaxed text-cream/90">
                "{item.text}"
              </p>
              <div className="mt-5 sm:mt-6 border-t border-white/10 pt-4 sm:pt-5">
                <div className="font-display text-sm sm:text-base font-semibold text-cream">{item.name}</div>
                <div className="text-xs sm:text-sm text-gold">{item.role}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

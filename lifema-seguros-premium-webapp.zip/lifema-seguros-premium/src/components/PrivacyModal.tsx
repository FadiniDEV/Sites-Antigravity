import { X } from "lucide-react";

export function PrivacyModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-[60] flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="max-h-[85vh] w-full max-w-2xl overflow-y-auto rounded-2xl border border-white/10 bg-navy-light p-5 sm:p-8 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-4 sm:mb-6 flex items-center justify-between">
          <h2 className="font-display text-xl sm:text-2xl font-bold text-cream">Política de Privacidade</h2>
          <button
            onClick={onClose}
            className="grid h-9 w-9 place-items-center rounded-full text-slate transition-colors hover:bg-white/10 hover:text-cream"
            aria-label="Fechar"
          >
            <X className="h-5 w-5" />
          </button>
        </div>
        <div className="space-y-4 text-sm leading-relaxed text-slate">
          <p>
            A Lifema Seguros valoriza a privacidade dos visitantes e clientes. Esta política
            descreve como coletamos, usamos e protegemos suas informações.
          </p>
          <p>
            <strong className="text-cream">Coleta de dados:</strong> podemos coletar informações
            pessoais como nome, telefone e e-mail quando você preenche nossos formulários de
            contato ou solicitação de cotação.
          </p>
          <p>
            <strong className="text-cream">Uso das informações:</strong> as informações são
            utilizadas exclusivamente para entrar em contato, apresentar opções de seguros e
            prestar atendimento.
          </p>
          <p>
            <strong className="text-cream">Proteção:</strong> adotamos medidas de segurança para
            proteger seus dados contra acesso não autorizado, alteração ou divulgação.
          </p>
          <p>
            <strong className="text-cream">Cookies:</strong> nosso site pode utilizar cookies para
            melhorar a experiência de navegação. Você pode desativá-los nas configurações do
            navegador.
          </p>
          <p>
            Ao utilizar este site, você concorda com os termos desta política. Em caso de dúvidas,
            entre em contato conosco.
          </p>
        </div>
      </div>
    </div>
  );
}

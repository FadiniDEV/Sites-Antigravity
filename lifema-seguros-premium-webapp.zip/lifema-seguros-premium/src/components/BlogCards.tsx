import { useReveal } from "../hooks/useReveal";
import { cn } from "../lib/utils";
import { Calendar, ArrowRight, ChevronRight } from "lucide-react";
import { blogPosts } from "../data/blogPosts";
import { Link } from "@tanstack/react-router";

export function BlogCards() {
  const { ref, visible } = useReveal<HTMLElement>();

  return (
    <section id="blog" ref={ref} className="relative overflow-hidden section-padding bg-navy-light/30">
      <div className="mx-auto max-w-7xl px-4">
        <div className={cn("mb-10 sm:mb-14 text-center reveal", visible && "reveal-visible")}>
          <span className="mb-2 sm:mb-3 inline-block text-xs sm:text-sm font-semibold uppercase tracking-wider text-gold">
            Blog
          </span>
          <h2 className="font-display text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold leading-tight text-cream text-balance">
            Informação também é proteção
          </h2>
          <p className="mt-3 sm:mt-4 text-xs sm:text-sm md:text-base text-slate">
            Confira nossos conteúdos mais recentes sobre seguros e planejamento financeiro.
          </p>
        </div>

        <div className="grid gap-5 sm:gap-6 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
          {blogPosts.slice(0, 3).map((post, i) => (
            <article
              key={post.id}
              className={cn(
                "group flex flex-col justify-between overflow-hidden rounded-2xl border border-white/10 bg-navy-light transition-all duration-300 hover:-translate-y-1 hover:border-gold/30 hover:shadow-xl hover:shadow-gold/5 reveal",
                visible && "reveal-visible"
              )}
              style={{ transitionDelay: `${i * 100}ms` }}
            >
              <div>
                <div className="relative h-44 sm:h-48 lg:h-52 overflow-hidden">
                  <img
                    src={post.image}
                    alt={post.title}
                    className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-navy-light/80 to-transparent" />
                  <span className="absolute left-3.5 top-3.5 sm:left-4 sm:top-4 rounded-full bg-gold px-2.5 py-0.5 sm:px-3 sm:py-1 text-[11px] sm:text-xs font-semibold text-navy">
                    {post.category}
                  </span>
                </div>
                <div className="p-5 sm:p-6">
                  <div className="mb-2.5 sm:mb-3 flex items-center gap-2 text-xs text-slate">
                    <Calendar className="h-3.5 w-3.5 text-gold" />
                    {post.date}
                  </div>
                  <h3 className="font-display text-base sm:text-lg font-bold leading-snug text-cream transition-colors group-hover:text-gold">
                    {post.title}
                  </h3>
                  <p className="mt-2 line-clamp-2 text-xs sm:text-sm text-slate">
                    {post.excerpt}
                  </p>
                </div>
              </div>

              <div className="p-5 pt-0 sm:p-6 sm:pt-0">
                <Link
                  to="/blog/$slug"
                  params={{ slug: post.slug }}
                  className="inline-flex items-center gap-1.5 text-xs sm:text-sm font-semibold text-gold transition-colors group-hover:text-gold-light"
                >
                  Ler artigo
                  <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                </Link>
              </div>
            </article>
          ))}
        </div>

        <div className="mt-8 sm:mt-12 text-center">
          <Link
            to="/blog"
            className="inline-flex w-full sm:w-auto items-center justify-center gap-2 rounded-lg border border-gold/40 bg-gold/10 px-6 py-3 text-sm font-semibold text-gold transition-all hover:bg-gold hover:text-navy"
          >
            Ver Todos os Artigos no Blog
            <ChevronRight className="h-4 w-4" />
          </Link>
        </div>
      </div>
    </section>
  );
}

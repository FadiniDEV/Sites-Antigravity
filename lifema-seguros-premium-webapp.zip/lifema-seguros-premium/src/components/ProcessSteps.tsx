import { useReveal } from "../hooks/useReveal";
import { cn } from "../lib/utils";

const steps = [
  {
    number: "01",
    title: "Conte o que você precisa",
    description: "Entramos em contato para entender seu perfil, seus bens e suas prioridades.",
  },
  {
    number: "02",
    title: "Analisamos seu perfil",
    description: "Avaliamos riscos, coberturas necessárias e o melhor momento para contratar.",
  },
  {
    number: "03",
    title: "Apresentamos as opções",
    description: "Você recebe uma comparação clara entre seguradoras e coberturas.",
  },
  {
    number: "04",
    title: "Você escolhe com segurança",
    description: "Com a nossa orientação, você contrata o seguro ideal com confiança.",
  },
];

export function ProcessSteps() {
  const { ref, visible } = useReveal<HTMLElement>();

  return (
    <section ref={ref} className="relative section-padding bg-navy-light/30">
      <div className="mx-auto max-w-7xl px-4">
        <div className={cn("mb-10 sm:mb-14 text-center reveal", visible && "reveal-visible")}>
          <span className="mb-2 sm:mb-3 inline-block text-xs sm:text-sm font-semibold uppercase tracking-wider text-gold">
            Como Funciona
          </span>
          <h2 className="font-display text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold leading-tight text-cream text-balance">
            Simplificamos a contratação do seu seguro
          </h2>
        </div>

        <div className="relative grid gap-6 sm:gap-8 grid-cols-1 sm:grid-cols-2 lg:grid-cols-4">
          {/* connector line desktop */}
          <div className="absolute left-10 right-10 top-7 hidden h-0.5 bg-gradient-to-r from-gold/20 via-gold/50 to-gold/20 lg:block" />

          {steps.map((step, i) => (
            <div
              key={step.number}
              className={cn(
                "relative reveal",
                visible && "reveal-visible"
              )}
              style={{ transitionDelay: `${i * 120}ms` }}
            >
              <div className="relative z-10 mx-auto mb-4 sm:mb-6 flex h-12 w-12 sm:h-14 sm:w-14 items-center justify-center rounded-full border-2 border-gold bg-navy shadow-lg shadow-gold/10">
                <span className="font-display text-xs sm:text-sm font-bold text-gold">{step.number}</span>
              </div>
              <h3 className="font-display text-center text-base sm:text-lg font-bold text-cream">
                {step.title}
              </h3>
              <p className="mt-2 text-center text-xs sm:text-sm leading-relaxed text-slate">
                {step.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

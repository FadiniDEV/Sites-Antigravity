import { useState } from "react";
import { useReveal } from "../hooks/useReveal";
import { cn } from "../lib/utils";
import { Phone, Mail, MapPin, Send, CheckCircle, MessageCircle, Loader2 } from "lucide-react";
import { COMPANY } from "../data/company";

const insuranceOptions = [
  "Seguro Auto",
  "Seguro Residencial",
  "Seguro de Vida",
  "Seguro Empresarial",
  "Seguro Saúde",
  "Seguro Viagem",
  "Seguro Moto",
  "Seguro Caminhão",
  "Seguro para Frotas",
  "Outro",
];

export function Contact() {
  const { ref, visible } = useReveal<HTMLElement>();
  const [form, setForm] = useState({
    name: "",
    phone: "",
    email: "",
    type: "",
    message: "",
  });
  const [errors, setErrors] = useState<{
    name?: string;
    phone?: string;
    email?: string;
    type?: string;
    message?: string;
  }>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const next: typeof errors = {};
    if (!form.name.trim()) next.name = "Informe seu nome";
    if (!form.phone.trim()) next.phone = "Informe seu telefone";
    if (!form.email.trim() || !/\S+@\S+\.\S+/.test(form.email)) next.email = "Informe um e-mail válido";
    if (!form.type) next.type = "Selecione um tipo de seguro";
    if (!form.message.trim()) next.message = "Escreva sua mensagem";
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setIsSubmitting(true);

    try {
      await fetch(`https://formsubmit.co/ajax/${COMPANY.email}`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
        },
        body: JSON.stringify({
          _subject: `Nova Solicitação de Cotação — ${form.name}`,
          Nome: form.name.trim(),
          Telefone: form.phone.trim(),
          Email: form.email.trim(),
          "Tipo de Seguro": form.type,
          Mensagem: form.message.trim(),
        }),
      });
    } catch (err) {
      console.error("Erro ao enviar e-mail:", err);
    } finally {
      setIsSubmitting(false);
      setSubmitted(true);
      setTimeout(() => {
        setForm({ name: "", phone: "", email: "", type: "", message: "" });
        setSubmitted(false);
      }, 5000);
    }
  };

  return (
    <section id="contato" ref={ref} className="relative overflow-hidden section-padding bg-navy-light/30">
      <div className="mx-auto max-w-7xl px-4">
        <div className="grid gap-8 md:gap-12 lg:grid-cols-2 lg:gap-16 xl:gap-20 items-start">
          <div className={cn("reveal", visible && "reveal-visible")}>
            <span className="mb-2 sm:mb-3 inline-block text-xs sm:text-sm font-semibold uppercase tracking-wider text-gold">
              Contato
            </span>
            <h2 className="font-display text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold leading-tight text-cream text-balance">
              Solicite uma cotação
            </h2>
            <p className="mt-4 sm:mt-6 text-base sm:text-lg leading-relaxed text-slate">
              Preencha o formulário e nossa equipe entrará em contato para apresentar as melhores
              opções para você.
            </p>

            <div className="mt-6 sm:mt-8 space-y-3.5 sm:space-y-4">
              <ContactItem
                icon={MessageCircle}
                label="WhatsApp"
                value={COMPANY.whatsapp}
                href={`https://wa.me/${COMPANY.whatsappNumber}?text=${encodeURIComponent(COMPANY.whatsappDefaultMessage)}`}
              />
              <ContactItem
                icon={Phone}
                label="Telefone"
                value={COMPANY.phone}
                href={`tel:${COMPANY.phoneRaw}`}
              />
              <ContactItem
                icon={Mail}
                label="E-mail"
                value={COMPANY.email}
                href={`mailto:${COMPANY.email}`}
              />
              <ContactItem
                icon={MapPin}
                label="Endereço"
                value={COMPANY.address}
                href={COMPANY.mapsUrl}
              />
            </div>
          </div>

          <form
            onSubmit={handleSubmit}
            className={cn(
              "rounded-2xl border border-white/10 bg-navy-light p-5 sm:p-7 md:p-8 shadow-xl shadow-black/10 reveal",
              visible && "reveal-visible"
            )}
            style={{ transitionDelay: "150ms" }}
          >
            {submitted ? (
              <div className="flex flex-col items-center justify-center py-10 sm:py-12 text-center">
                <div className="mb-4 grid h-14 w-14 sm:h-16 sm:w-16 place-items-center rounded-full bg-gold/10 text-gold">
                  <CheckCircle className="h-7 w-7 sm:h-8 sm:w-8" />
                </div>
                <h3 className="font-display text-lg sm:text-xl font-bold text-cream">Mensagem enviada!</h3>
                <p className="mt-2 text-xs sm:text-sm text-slate">
                  Agradecemos o contato. Retornaremos em breve.
                </p>
              </div>
            ) : (
              <>
                <div className="grid gap-4 sm:gap-5 sm:grid-cols-2">
                  <Field label="Nome" error={errors.name}>
                    <input
                      type="text"
                      value={form.name}
                      onChange={(e) => setForm({ ...form, name: e.target.value })}
                      placeholder="Seu nome completo"
                      className="w-full rounded-lg border border-white/10 bg-navy px-3.5 sm:px-4 py-2.5 sm:py-3 text-sm text-cream outline-none transition-colors placeholder:text-slate/50 focus:border-gold"
                    />
                  </Field>
                  <Field label="Telefone" error={errors.phone}>
                    <input
                      type="tel"
                      value={form.phone}
                      onChange={(e) => setForm({ ...form, phone: e.target.value })}
                      placeholder="(00) 00000-0000"
                      className="w-full rounded-lg border border-white/10 bg-navy px-3.5 sm:px-4 py-2.5 sm:py-3 text-sm text-cream outline-none transition-colors placeholder:text-slate/50 focus:border-gold"
                    />
                  </Field>
                  <Field label="E-mail" error={errors.email}>
                    <input
                      type="email"
                      value={form.email}
                      onChange={(e) => setForm({ ...form, email: e.target.value })}
                      placeholder="seu@email.com"
                      className="w-full rounded-lg border border-white/10 bg-navy px-3.5 sm:px-4 py-2.5 sm:py-3 text-sm text-cream outline-none transition-colors placeholder:text-slate/50 focus:border-gold"
                    />
                  </Field>
                  <Field label="Tipo de Seguro" error={errors.type}>
                    <select
                      value={form.type}
                      onChange={(e) => setForm({ ...form, type: e.target.value })}
                      className="w-full rounded-lg border border-white/10 bg-navy px-3.5 sm:px-4 py-2.5 sm:py-3 text-sm text-cream outline-none transition-colors focus:border-gold"
                    >
                      <option value="" disabled>
                        Selecione
                      </option>
                      {insuranceOptions.map((opt) => (
                        <option key={opt} value={opt}>
                          {opt}
                        </option>
                      ))}
                    </select>
                  </Field>
                </div>
                <Field className="mt-4 sm:mt-5" label="Mensagem" error={errors.message}>
                  <textarea
                    value={form.message}
                    onChange={(e) => setForm({ ...form, message: e.target.value })}
                    placeholder="Conte um pouco sobre o que você precisa..."
                    rows={4}
                    className="w-full rounded-lg border border-white/10 bg-navy px-3.5 sm:px-4 py-2.5 sm:py-3 text-sm text-cream outline-none transition-colors placeholder:text-slate/50 focus:border-gold"
                  />
                </Field>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="group mt-5 sm:mt-6 inline-flex w-full sm:w-auto items-center justify-center gap-2 rounded-lg bg-gold px-6 py-3 sm:py-3.5 text-sm sm:text-base font-semibold text-navy transition-all hover:bg-gold-light disabled:opacity-70"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin" />
                      Enviando...
                    </>
                  ) : (
                    <>
                      <Send className="h-4 w-4" />
                      Solicitar Cotação
                    </>
                  )}
                </button>
              </>
            )}
          </form>
        </div>
      </div>
    </section>
  );
}

function ContactItem({
  icon: Icon,
  label,
  value,
  href,
}: {
  icon: React.ElementType;
  label: string;
  value: string;
  href?: string;
}) {
  return (
    <div className="flex items-start gap-3 sm:gap-4">
      <div className="grid h-10 w-10 sm:h-11 sm:w-11 shrink-0 place-items-center rounded-lg bg-gold/10 text-gold">
        <Icon className="h-4 w-4 sm:h-5 sm:w-5" />
      </div>
      <div className="min-w-0 flex-1">
        <div className="text-[11px] sm:text-xs font-semibold uppercase tracking-wider text-slate">{label}</div>
        {href ? (
          <a
            href={href}
            target={href.startsWith("http") ? "_blank" : undefined}
            rel={href.startsWith("http") ? "noopener noreferrer" : undefined}
            className="mt-0.5 block text-sm sm:text-base text-cream transition-colors hover:text-gold break-words"
          >
            {value}
          </a>
        ) : (
          <div className="mt-0.5 text-sm sm:text-base text-cream break-words">{value}</div>
        )}
      </div>
    </div>
  );
}

function Field({
  label,
  error,
  children,
  className,
}: {
  label: string;
  error?: string | undefined;
  children: React.ReactNode;
  className?: string | undefined;
}) {
  return (
    <div className={className}>
      <label className="mb-1 sm:mb-1.5 block text-xs sm:text-sm font-medium text-cream">{label}</label>
      {children}
      {error && <span className="mt-1 block text-xs text-red-400">{error}</span>}
    </div>
  );
}

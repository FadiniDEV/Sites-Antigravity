import { Phone, Mail, MapPin, Instagram, Facebook } from "lucide-react";
import logoImg from "../assets/lifema-logo.png";
import { COMPANY } from "../data/company";

const quickLinks = [
  { label: "Início", href: "#inicio" },
  { label: "Sobre Nós", href: "#sobre" },
  { label: "Seguros", href: "#seguros" },
  { label: "Benefícios", href: "#beneficios" },
  { label: "Blog", href: "#blog" },
  { label: "Contato", href: "#contato" },
];

const insuranceLinks = [
  "Seguro Auto",
  "Seguro Residencial",
  "Seguro de Vida",
  "Seguro Empresarial",
  "Seguro Saúde",
  "Seguro Viagem",
];

interface FooterProps {
  onPrivacy: () => void;
  onTerms: () => void;
}

export function Footer({ onPrivacy, onTerms }: FooterProps) {
  const handleAnchor = (href: string) => {
    const id = href.replace("#", "");
    const el = document.getElementById(id);
    if (el) {
      const top = el.getBoundingClientRect().top + window.scrollY - 88;
      window.scrollTo({ top, behavior: "smooth" });
    }
  };

  return (
    <footer className="relative overflow-hidden border-t border-white/10 bg-navy-light">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:py-16 lg:py-20">
        <div className="grid gap-8 sm:gap-10 sm:grid-cols-2 lg:grid-cols-4">
          {/* brand */}
          <div className="sm:col-span-2 lg:col-span-1">
            <a href="#inicio" onClick={(e) => { e.preventDefault(); handleAnchor("#inicio"); }} className="inline-flex items-center gap-3">
              <img
                src={logoImg}
                alt={COMPANY.name}
                className="h-10 sm:h-12 w-auto object-contain"
              />
              <span className="font-display text-base sm:text-lg font-bold text-cream">{COMPANY.name}</span>
            </a>
            <p className="mt-3 sm:mt-4 max-w-xs text-xs sm:text-sm leading-relaxed text-slate">
              Corretora de seguros brasileira dedicada a proteger pessoas, famílias e empresas com
              soluções personalizadas.
            </p>
            <div className="mt-5 sm:mt-6 flex gap-3">
              <SocialIcon href={COMPANY.social.instagram} icon={Instagram} label="Instagram" />
              <SocialIcon href={COMPANY.social.facebook} icon={Facebook} label="Facebook" />
            </div>
          </div>

          {/* quick links */}
          <div>
            <h4 className="mb-3 sm:mb-4 font-display text-sm sm:text-base font-bold text-cream">Links Rápidos</h4>
            <ul className="space-y-2 sm:space-y-2.5">
              {quickLinks.map((link) => (
                <li key={link.href}>
                  <a
                    href={link.href}
                    onClick={(e) => {
                      e.preventDefault();
                      handleAnchor(link.href);
                    }}
                    className="text-xs sm:text-sm text-slate transition-colors hover:text-gold"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* insurance links */}
          <div>
            <h4 className="mb-3 sm:mb-4 font-display text-sm sm:text-base font-bold text-cream">Seguros</h4>
            <ul className="space-y-2 sm:space-y-2.5">
              {insuranceLinks.map((link) => (
                <li key={link}>
                  <span className="text-xs sm:text-sm text-slate">{link}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* contact */}
          <div>
            <h4 className="mb-3 sm:mb-4 font-display text-sm sm:text-base font-bold text-cream">Contato</h4>
            <ul className="space-y-3">
              <li className="flex items-start gap-2.5 sm:gap-3 text-xs sm:text-sm text-slate">
                <Phone className="mt-0.5 h-4 w-4 shrink-0 text-gold" />
                <a href={`tel:${COMPANY.phoneRaw}`} className="transition-colors hover:text-gold">
                  {COMPANY.phone}
                </a>
              </li>
              <li className="flex items-start gap-2.5 sm:gap-3 text-xs sm:text-sm text-slate">
                <Mail className="mt-0.5 h-4 w-4 shrink-0 text-gold" />
                <a
                  href={`mailto:${COMPANY.email}`}
                  className="transition-colors hover:text-gold break-all font-medium"
                >
                  {COMPANY.email}
                </a>
              </li>
              <li className="flex items-start gap-2.5 sm:gap-3 text-xs sm:text-sm text-slate">
                <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-gold" />
                <a
                  href={COMPANY.mapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="transition-colors hover:text-gold"
                >
                  {COMPANY.address}
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* bottom bar */}
      <div className="border-t border-white/10 bg-navy">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-3 sm:gap-4 px-4 py-5 sm:py-6 sm:flex-row">
          <p className="text-center text-xs text-slate sm:text-left">
            © {new Date().getFullYear()} {COMPANY.name}. Todos os direitos reservados.
          </p>
          <div className="flex gap-4 sm:gap-6">
            <button
              onClick={onPrivacy}
              className="text-xs text-slate transition-colors hover:text-gold"
            >
              Política de Privacidade
            </button>
            <button
              onClick={onTerms}
              className="text-xs text-slate transition-colors hover:text-gold"
            >
              Termos de Uso
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
}

function SocialIcon({ href, icon: Icon, label }: { href: string; icon: React.ElementType; label: string }) {
  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      className="grid h-9 w-9 place-items-center rounded-full border border-white/10 text-slate transition-colors hover:border-gold hover:text-gold"
      aria-label={label}
    >
      <Icon className="h-4 w-4" />
    </a>
  );
}

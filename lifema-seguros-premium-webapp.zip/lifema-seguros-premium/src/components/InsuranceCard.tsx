import { Link } from "@tanstack/react-router";
import { cn } from "../lib/utils";
import type { LucideIcon } from "lucide-react";

interface InsuranceCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
  slug: string;
  className?: string;
}

export function InsuranceCard({ icon: Icon, title, description, slug, className }: InsuranceCardProps) {
  return (
    <div
      className={cn(
        "group relative flex flex-col justify-between overflow-hidden rounded-2xl border border-white/10 bg-navy-light p-5 sm:p-6 lg:p-7 transition-all duration-300 hover:-translate-y-1 hover:border-gold/30 hover:shadow-xl hover:shadow-gold/5",
        className
      )}
    >
      <div>
        <div className="mb-4 sm:mb-5 flex h-12 w-12 sm:h-14 sm:w-14 items-center justify-center rounded-xl bg-gradient-to-br from-gold/20 to-gold/5 text-gold transition-transform duration-300 group-hover:scale-110">
          <Icon className="h-6 w-6 sm:h-7 sm:w-7" />
        </div>
        <h3 className="font-display text-lg sm:text-xl font-bold text-cream">{title}</h3>
        <p className="mt-2.5 sm:mt-3 text-xs sm:text-sm leading-relaxed text-slate">{description}</p>
      </div>
      <Link
        to="/blog/$slug"
        params={{ slug }}
        className="mt-4 sm:mt-6 inline-flex items-center gap-1.5 self-start text-xs sm:text-sm font-semibold text-gold transition-colors hover:text-gold-light"
      >
        Saiba mais
        <span className="transition-transform group-hover:translate-x-1">→</span>
      </Link>
    </div>
  );
}

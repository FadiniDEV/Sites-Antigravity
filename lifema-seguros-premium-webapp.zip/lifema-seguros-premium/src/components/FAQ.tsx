import { useState } from "react";
import { useReveal } from "../hooks/useReveal";
import { cn } from "../lib/utils";
import { ChevronDown, HelpCircle } from "lucide-react";

const faqs = [
  {
    question: "O que faz uma corretora de seguros?",
    answer:
      "A corretora atua como intermediária entre o cliente e as seguradoras. Nossa função é entender suas necessidades, apresentar opções compatíveis, esclarecer coberturas e acompanhar a contratação e eventuais sinistros.",
  },
  {
    question: "Como solicitar uma cotação?",
    answer:
      "Você pode clicar no botão 'Cotação de Seguros' no menu ou preencher o formulário de contato. Entraremos em contato para entender seu perfil e enviar as melhores opções.",
  },
  {
    question: "Quais tipos de seguros a Lifema oferece?",
    answer:
      "Trabalhamos com seguro auto, residencial, vida, empresarial, saúde, viagem, moto, caminhão e frotas. Também podemos estudar outras necessidades específicas.",
  },
  {
    question: "A contratação é feita diretamente com a seguradora?",
    answer:
      "A apólice é emitida pela seguradora escolhida, mas a Lifema acompanha todo o processo, tirando dúvidas e ajudando na escolha da cobertura mais adequada.",
  },
  {
    question: "Como funciona o atendimento em caso de sinistro?",
    answer:
      "Orientamos nossos clientes sobre o canal correto de acionamento da seguradora e, quando necessário, acompanhamos a comunicação para facilitar a resolução.",
  },
];

export function FAQ() {
  const { ref, visible } = useReveal<HTMLElement>();
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <section ref={ref} className="relative overflow-hidden section-padding">
      <div className="absolute right-0 top-0 h-[400px] w-[400px] translate-x-1/2 rounded-full bg-gold/5 blur-[100px]" />

      <div className="relative mx-auto max-w-4xl px-4">
        <div className={cn("mb-10 sm:mb-14 text-center reveal", visible && "reveal-visible")}>
          <span className="mb-2 sm:mb-3 inline-block text-xs sm:text-sm font-semibold uppercase tracking-wider text-gold">
            Dúvidas
          </span>
          <h2 className="font-display text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold leading-tight text-cream text-balance">
            Perguntas Frequentes
          </h2>
        </div>

        <div className="space-y-3 sm:space-y-4">
          {faqs.map((faq, i) => (
            <div
              key={i}
              className={cn(
                "overflow-hidden rounded-2xl border border-white/10 bg-navy-light transition-all reveal",
                visible && "reveal-visible",
                openIndex === i && "border-gold/30"
              )}
              style={{ transitionDelay: `${i * 80}ms` }}
            >
              <button
                onClick={() => setOpenIndex(openIndex === i ? null : i)}
                className="flex w-full items-center justify-between gap-3 px-4 py-4 sm:px-6 sm:py-5 text-left"
                aria-expanded={openIndex === i}
              >
                <span className="flex items-center gap-2.5 sm:gap-3 font-display text-sm sm:text-base font-semibold text-cream">
                  <HelpCircle className="h-4 w-4 sm:h-5 sm:w-5 shrink-0 text-gold" />
                  {faq.question}
                </span>
                <ChevronDown
                  className={cn(
                    "h-4 w-4 sm:h-5 sm:w-5 shrink-0 text-gold transition-transform duration-300",
                    openIndex === i && "rotate-180"
                  )}
                />
              </button>
              <div
                className={cn(
                  "overflow-hidden px-4 sm:px-6 transition-all duration-300 ease-in-out",
                  openIndex === i ? "max-h-96 pb-4 sm:pb-6" : "max-h-0"
                )}
              >
                <p className="pl-6 sm:pl-8 text-xs sm:text-sm md:text-base leading-relaxed text-slate">
                  {faq.answer}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

import { X } from "lucide-react";

export function TermsModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-[60] flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="max-h-[85vh] w-full max-w-2xl overflow-y-auto rounded-2xl border border-white/10 bg-navy-light p-5 sm:p-8 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-4 sm:mb-6 flex items-center justify-between">
          <h2 className="font-display text-xl sm:text-2xl font-bold text-cream">Termos de Uso</h2>
          <button
            onClick={onClose}
            className="grid h-9 w-9 place-items-center rounded-full text-slate transition-colors hover:bg-white/10 hover:text-cream"
            aria-label="Fechar"
          >
            <X className="h-5 w-5" />
          </button>
        </div>
        <div className="space-y-4 text-sm leading-relaxed text-slate">
          <p>
            Ao acessar e usar este site, você aceita os termos e condições descritos abaixo. Se
            não concordar, por favor, não utilize o site.
          </p>
          <p>
            <strong className="text-cream">Propriedade intelectual:</strong> todo o conteúdo
            disponível neste site, incluindo textos, imagens, logotipos e marcas, é de propriedade
            da Lifema Seguros ou de seus licenciadores.
          </p>
          <p>
            <strong className="text-cream">Uso permitido:</strong> o site destina-se a informar
            sobre produtos e serviços de seguros. É proibido o uso para fins ilegais ou que possam
            prejudicar a corretora ou terceiros.
          </p>
          <p>
            <strong className="text-cream">Precisão das informações:</strong> as informações
            publicadas têm caráter informativo e não substituem a apólice contratada ou a consulta
            com um corretor.
          </p>
          <p>
            <strong className="text-cream">Links externos:</strong> este site pode conter links
            para sites de terceiros. Não nos responsabilizamos pelo conteúdo ou práticas de
            privacidade desses sites.
          </p>
          <p>
            A Lifema Seguros pode alterar estes termos a qualquer momento. Recomendamos que você
            os consulte periodicamente.
          </p>
        </div>
      </div>
    </div>
  );
}

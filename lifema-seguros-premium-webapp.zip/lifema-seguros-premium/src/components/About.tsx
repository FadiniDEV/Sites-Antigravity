import { useReveal } from "../hooks/useReveal";
import { cn } from "../lib/utils";
import aboutImg from "../assets/about.jpg";
import { ArrowRight, Award } from "lucide-react";

const stats = [
  { value: "+10", label: "anos de experiência" },
  { value: "+5k", label: "clientes atendidos" },
  { value: "+20", label: "seguradoras parceiras" },
];

export function About() {
  const { ref, visible } = useReveal<HTMLElement>();

  const handleAnchor = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      const top = el.getBoundingClientRect().top + window.scrollY - 88;
      window.scrollTo({ top, behavior: "smooth" });
    }
  };

  return (
    <section id="sobre" ref={ref} className="relative overflow-hidden section-padding">
      <div className="absolute -left-40 top-20 h-[400px] w-[400px] rounded-full bg-gold/5 blur-[100px]" />

      <div className="relative mx-auto max-w-7xl px-4">
        <div className="grid items-center gap-10 md:gap-14 lg:grid-cols-2 lg:gap-16 xl:gap-20">
          {/* image side */}
          <div
            className={cn(
              "relative order-2 lg:order-1 reveal",
              visible && "reveal-visible"
            )}
          >
            <div className="relative overflow-hidden rounded-2xl border border-white/10 shadow-2xl shadow-black/30">
              <img
                src={aboutImg}
                alt="Consultoria de seguros Lifema"
                className="h-[320px] sm:h-[420px] md:h-[480px] lg:h-[540px] xl:h-[600px] w-full object-cover"
                width={800}
                height={1000}
                loading="lazy"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-navy/60 via-transparent to-transparent" />
            </div>

            {/* floating badge */}
            <div className="absolute -bottom-4 right-2 sm:-bottom-6 sm:-right-4 lg:-right-6 max-w-[230px] sm:max-w-[280px] lg:max-w-xs rounded-xl border border-gold/20 bg-navy-light p-4 sm:p-5 shadow-xl shadow-black/30">
              <div className="mb-2 sm:mb-3 flex items-center gap-2.5 sm:gap-3">
                <div className="grid h-8 w-8 sm:h-10 sm:w-10 place-items-center rounded-full bg-gold/10 text-gold">
                  <Award className="h-4 w-4 sm:h-5 sm:w-5" />
                </div>
                <span className="font-display text-sm sm:text-base lg:text-lg font-bold text-cream">
                  Experiência que protege
                </span>
              </div>
              <p className="text-xs sm:text-sm text-slate leading-relaxed">
                Mais de uma década conectando pessoas e empresas às melhores soluções de seguros.
              </p>
            </div>
          </div>

          {/* content side */}
          <div
            className={cn(
              "order-1 lg:order-2 reveal",
              visible && "reveal-visible"
            )}
            style={{ transitionDelay: "150ms" }}
          >
            <span className="mb-3 inline-block text-xs sm:text-sm font-semibold uppercase tracking-wider text-gold">
              Sobre Nós
            </span>
            <h2 className="font-display text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold leading-tight text-cream text-balance">
              Seguro certo começa com{" "}
              <span className="text-gold">orientação certa</span>.
            </h2>
            <p className="mt-4 sm:mt-6 text-base sm:text-lg leading-relaxed text-slate">
              A Lifema Seguros auxilia clientes na busca por soluções de proteção adequadas às
              suas necessidades. Com uma equipe experiente e acesso a diversas seguradoras, nosso
              trabalho é simplificar escolhas importantes.
            </p>
            <p className="mt-3 sm:mt-4 text-sm sm:text-base leading-relaxed text-slate/80">
              Entendemos que cada pessoa, família e empresa enfrenta riscos diferentes. Por isso,
              oferecemos atendimento personalizado e opções sob medida, para que você contrate com
              clareza e segurança.
            </p>

            <div className="mt-6 sm:mt-8 grid grid-cols-3 gap-2 sm:gap-4 border-y border-white/10 py-4 sm:py-6">
              {stats.map((stat) => (
                <div key={stat.label} className="text-center">
                  <div className="font-display text-xl sm:text-2xl lg:text-3xl font-bold text-gold">
                    {stat.value}
                  </div>
                  <div className="mt-1 text-[11px] sm:text-xs lg:text-sm text-slate">{stat.label}</div>
                </div>
              ))}
            </div>

            <button
              onClick={() => handleAnchor("contato")}
              className="group mt-6 sm:mt-8 inline-flex w-full sm:w-auto items-center justify-center gap-2 rounded-lg bg-gold px-6 py-3 text-sm font-semibold text-navy transition-colors hover:bg-gold-light"
            >
              Conheça a Lifema
              <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}

import { n as __toESM } from "./_runtime.mjs";
import { n as blogPosts } from "./_ssr/blogPosts-CUNdaIJl.mjs";
import { n as require_jsx_runtime, r as require_react } from "./_libs/react+tanstack__react-query.mjs";
import { H as ArrowLeft, I as Calendar, N as ChevronRight, V as ArrowRight, j as CircleCheck, k as Clock, r as User, u as Share2 } from "./_libs/lucide-react.mjs";
import { i as TermsModal, n as Header, r as PrivacyModal, t as Footer } from "./_ssr/TermsModal-Bfn12m1N.mjs";
import { g as useParams, h as Link } from "./_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_slug-Cnmni_aC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function BlogPostPage() {
	const { slug } = useParams({ from: "/blog/$slug" });
	const [privacyOpen, setPrivacyOpen] = (0, import_react.useState)(false);
	const [termsOpen, setTermsOpen] = (0, import_react.useState)(false);
	const [copied, setCopied] = (0, import_react.useState)(false);
	const post = blogPosts.find((p) => p.slug === slug);
	const handleShare = () => {
		if (navigator.clipboard) {
			navigator.clipboard.writeText(window.location.href);
			setCopied(true);
			setTimeout(() => setCopied(false), 3e3);
		}
	};
	if (!post) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-screen flex-col justify-between bg-navy text-cream",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "flex flex-1 items-center justify-center px-4 py-32 text-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-w-md",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-display text-3xl font-bold text-cream sm:text-4xl",
							children: "Artigo não encontrado"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-slate",
							children: "O post que você está procurando não existe ou foi removido."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-8",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/blog",
								className: "inline-flex items-center gap-2 rounded-lg bg-gold px-6 py-3 text-sm font-semibold text-navy transition-all hover:bg-gold-light",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-4 w-4" }), "Voltar para o Blog"]
							})
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {
				onPrivacy: () => setPrivacyOpen(true),
				onTerms: () => setTermsOpen(true)
			})
		]
	});
	const relatedPosts = blogPosts.filter((p) => p.slug !== post.slug).slice(0, 3);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-navy text-cream",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "pt-24 sm:pt-32",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mx-auto max-w-4xl px-4 py-3 sm:py-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
							className: "flex items-center gap-1.5 sm:gap-2 text-xs text-slate sm:text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/",
									className: "hover:text-gold transition-colors shrink-0",
									children: "Início"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-3.5 w-3.5 text-slate/50 shrink-0" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/blog",
									className: "hover:text-gold transition-colors shrink-0",
									children: "Blog"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-3.5 w-3.5 text-slate/50 shrink-0" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "truncate text-gold",
									children: post.title
								})
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "mx-auto max-w-4xl px-4 py-4 sm:py-8",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
								className: "mb-8 sm:mb-10",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mb-3 sm:mb-4 flex flex-wrap items-center gap-2.5 sm:gap-3",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "rounded-full bg-gold px-3 py-0.5 sm:px-3.5 sm:py-1 text-xs font-bold text-navy",
												children: post.category
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "flex items-center gap-1.5 text-xs text-slate",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "h-3.5 w-3.5 text-gold" }), post.date]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "flex items-center gap-1.5 text-xs text-slate",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "h-3.5 w-3.5 text-gold" }), post.readTime]
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
										className: "font-display text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-extrabold leading-tight text-cream text-balance",
										children: post.title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-4 sm:mt-6 text-base sm:text-lg md:text-xl leading-relaxed text-slate",
										children: post.excerpt
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-6 sm:mt-8 flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-y border-white/10 py-3.5 sm:py-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "grid h-9 w-9 sm:h-10 sm:w-10 place-items-center rounded-full bg-gold/10 text-gold border border-gold/20",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "h-4 w-4 sm:h-5 sm:w-5" })
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-xs sm:text-sm font-semibold text-cream",
												children: post.author.name
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-[11px] sm:text-xs text-slate",
												children: post.author.role
											})] })]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											onClick: handleShare,
											className: "inline-flex w-full sm:w-auto items-center justify-center gap-2 rounded-lg border border-white/10 bg-navy-light px-3.5 sm:px-4 py-2 text-xs font-medium text-cream transition-colors hover:border-gold/40 hover:text-gold",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, { className: "h-3.5 w-3.5" }), copied ? "Link copiado!" : "Compartilhar"]
										})]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mb-8 sm:mb-12 overflow-hidden rounded-2xl sm:rounded-3xl border border-white/10 bg-navy-light shadow-2xl",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: post.image,
									alt: post.title,
									className: "h-auto w-full object-cover max-h-[480px]"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "prose prose-invert max-w-none space-y-6 sm:space-y-8 text-sm sm:text-base md:text-lg leading-relaxed text-slate",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-base sm:text-lg md:text-xl font-medium text-cream/90 leading-relaxed border-l-2 border-gold pl-3.5 sm:pl-4 py-1 bg-gold/5 rounded-r-lg",
										children: post.content.intro
									}),
									post.content.sections.map((sec, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-3 sm:space-y-4 pt-3 sm:pt-4",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
												className: "font-display text-xl sm:text-2xl md:text-3xl font-bold text-cream",
												children: sec.title
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-slate leading-relaxed",
												children: sec.text
											}),
											sec.bullets && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
												className: "space-y-2 pt-2",
												children: sec.bullets.map((bullet, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
													className: "flex items-start gap-2.5 sm:gap-3 text-xs sm:text-base text-cream/90",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "mt-1 h-3.5 w-3.5 sm:h-4 sm:w-4 shrink-0 text-gold" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: bullet })]
												}, idx))
											})
										]
									}, i)),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "my-8 sm:my-10 rounded-2xl border border-gold/30 bg-gradient-to-r from-navy-light to-navy p-5 sm:p-8 shadow-xl",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
												className: "font-display text-lg sm:text-xl md:text-2xl font-bold text-cream",
												children: "Quer cotar este seguro sem compromisso?"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-2 text-xs sm:text-sm md:text-base text-slate",
												children: "Fale com nossos corretores na Lifema Seguros e encontre a cobertura perfeita com o melhor preço."
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
												href: "/#contato",
												className: "mt-5 sm:mt-6 inline-flex w-full sm:w-auto items-center justify-center gap-2 rounded-lg bg-gold px-5 sm:px-6 py-2.5 sm:py-3 text-xs sm:text-sm font-semibold text-navy transition-all hover:bg-gold-light",
												children: ["Solicitar Cotação Agora", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-4 w-4" })]
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "pt-3 sm:pt-4",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-slate leading-relaxed",
											children: post.content.conclusion
										})
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-12 sm:mt-16 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 border-t border-white/10 pt-6 sm:pt-8",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/blog",
									className: "inline-flex items-center justify-center gap-2 rounded-lg border border-white/10 bg-navy-light px-4 sm:px-5 py-2 sm:py-2.5 text-xs sm:text-sm font-semibold text-cream transition-colors hover:border-gold/40 hover:text-gold",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-4 w-4" }), "Voltar ao Blog"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									href: "/#contato",
									className: "inline-flex items-center justify-center gap-2 text-xs sm:text-sm font-semibold text-gold hover:underline",
									children: ["Falar com corretor", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-4 w-4" })]
								})]
							})
						]
					}),
					relatedPosts.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						className: "border-t border-white/10 bg-navy-light/30 py-12 sm:py-16",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto max-w-7xl px-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-6 sm:mb-10 flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-display text-xl sm:text-2xl md:text-3xl font-bold text-cream",
									children: "Artigos Relacionados"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/blog",
									className: "inline-flex items-center gap-1.5 text-xs sm:text-sm font-semibold text-gold hover:underline",
									children: ["Ver todos", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-4 w-4" })]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid gap-5 sm:gap-6 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3",
								children: relatedPosts.map((rel) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
									className: "group flex flex-col justify-between overflow-hidden rounded-2xl border border-white/10 bg-navy-light transition-all duration-300 hover:-translate-y-1 hover:border-gold/40 hover:shadow-xl",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative h-44 overflow-hidden",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
												src: rel.image,
												alt: rel.title,
												className: "h-full w-full object-cover transition-transform duration-500 group-hover:scale-105",
												loading: "lazy"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-navy-light/80 to-transparent" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "absolute left-4 top-4 rounded-full bg-gold px-3 py-0.5 text-xs font-semibold text-navy",
												children: rel.category
											})
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "mb-2 text-xs text-slate",
											children: rel.date
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "font-display text-base font-bold leading-snug text-cream group-hover:text-gold transition-colors",
											children: rel.title
										})]
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "p-5 pt-0",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
											to: "/blog/$slug",
											params: { slug: rel.slug },
											className: "inline-flex items-center gap-1.5 text-xs font-semibold text-gold hover:text-gold-light",
											children: ["Ler artigo", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-3.5 w-3.5" })]
										})
									})]
								}, rel.id))
							})]
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {
				onPrivacy: () => setPrivacyOpen(true),
				onTerms: () => setTermsOpen(true)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrivacyModal, {
				open: privacyOpen,
				onClose: () => setPrivacyOpen(false)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TermsModal, {
				open: termsOpen,
				onClose: () => setTermsOpen(false)
			})
		]
	});
}
//#endregion
export { BlogPostPage as component };

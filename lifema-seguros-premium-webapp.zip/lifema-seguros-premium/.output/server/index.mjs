globalThis.__nitro_main__ = import.meta.url;
import { n as HTTPError, r as defineLazyEventHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { t as HookableCore } from "./_libs/hookable.mjs";
import { r as FastResponse } from "./_libs/h3-v2+rou3+srvx.mjs";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/assets/blog-3YPA2Ks4.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2694-/RqcUxFpFN+h6E8nQ/2urDtCwUI\"",
		"mtime": "2026-08-14T18:51:49.918Z",
		"size": 9876,
		"path": "../public/assets/blog-3YPA2Ks4.js"
	},
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"ae-hLVBrSrDdpIw3Xl0dJPRkupPepQ\"",
		"mtime": "2026-08-13T17:30:03.354Z",
		"size": 174,
		"path": "../public/robots.txt"
	},
	"/favicon.png": {
		"type": "image/png",
		"etag": "\"4eaba-4igV8nSLND33XL6hjmFlheAqMu0\"",
		"mtime": "2026-08-14T12:31:11.186Z",
		"size": 322234,
		"path": "../public/favicon.png"
	},
	"/lifema-logo.png": {
		"type": "image/png",
		"etag": "\"4eaba-4igV8nSLND33XL6hjmFlheAqMu0\"",
		"mtime": "2026-08-14T12:31:11.186Z",
		"size": 322234,
		"path": "../public/lifema-logo.png"
	},
	"/assets/about-CyJqJ72t.jpg": {
		"type": "image/jpeg",
		"etag": "\"16c9d-ixBrz/BNOQb/45QvIpl3ZXUQzj0\"",
		"mtime": "2026-08-14T18:51:49.920Z",
		"size": 93341,
		"path": "../public/assets/about-CyJqJ72t.jpg"
	},
	"/assets/blog-empresarial-BEIhaF8e.jpg": {
		"type": "image/jpeg",
		"etag": "\"1b438-qndLQXNazssxJ69Cfog/dchUIdE\"",
		"mtime": "2026-08-14T18:51:49.925Z",
		"size": 111672,
		"path": "../public/assets/blog-empresarial-BEIhaF8e.jpg"
	},
	"/assets/blog-auto-D1l0y7oU.jpg": {
		"type": "image/jpeg",
		"etag": "\"17e80-sJRHN/rXBt5M0OADLS0V/rWsQsw\"",
		"mtime": "2026-08-14T18:51:49.921Z",
		"size": 97920,
		"path": "../public/assets/blog-auto-D1l0y7oU.jpg"
	},
	"/assets/blog-escolher-Doc9vFOs.jpg": {
		"type": "image/jpeg",
		"etag": "\"15014-nlryVso9jq8rT8JafNnUrbaIh2c\"",
		"mtime": "2026-08-14T18:51:49.927Z",
		"size": 86036,
		"path": "../public/assets/blog-escolher-Doc9vFOs.jpg"
	},
	"/assets/blog-residencial-BLETtMws.jpg": {
		"type": "image/jpeg",
		"etag": "\"227b1-BDx9E9qKGiNjcqJlfuWOdXhXOf8\"",
		"mtime": "2026-08-14T18:51:49.931Z",
		"size": 141233,
		"path": "../public/assets/blog-residencial-BLETtMws.jpg"
	},
	"/assets/clock-BCduV_yT.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9e-9uEldsR0aMsdeEFY7G8W2Wn5xw0\"",
		"mtime": "2026-08-14T18:51:49.919Z",
		"size": 158,
		"path": "../public/assets/clock-BCduV_yT.js"
	},
	"/assets/blog-vida-QvDqA9yj.jpg": {
		"type": "image/jpeg",
		"etag": "\"1ad26-YONmG/TRJjDXRgT21u+JioraNv8\"",
		"mtime": "2026-08-14T18:51:49.935Z",
		"size": 109862,
		"path": "../public/assets/blog-vida-QvDqA9yj.jpg"
	},
	"/assets/routes-Lj6V0XYE.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9ec8-1+IaMQskf8Pwek+d7bcelPVB79c\"",
		"mtime": "2026-08-14T18:51:49.919Z",
		"size": 40648,
		"path": "../public/assets/routes-Lj6V0XYE.js"
	},
	"/assets/_slug-B5_ikYhI.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"25ba-UPgjDYy6bujmCcU9LhlJLwI9bQE\"",
		"mtime": "2026-08-14T18:51:49.916Z",
		"size": 9658,
		"path": "../public/assets/_slug-B5_ikYhI.js"
	},
	"/assets/TermsModal-Bf18P88a.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"aa5d-wC66cnp2JQvF+Fojdc1oKGvAmDs\"",
		"mtime": "2026-08-14T18:51:49.915Z",
		"size": 43613,
		"path": "../public/assets/TermsModal-Bf18P88a.js"
	},
	"/assets/index-FTFl7bOT.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"59ce6-auFJZLFnIhQTWXnsRL8EggKg//M\"",
		"mtime": "2026-08-14T18:51:49.915Z",
		"size": 367846,
		"path": "../public/assets/index-FTFl7bOT.js"
	},
	"/assets/styles-BU2rh9c_.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"1a4df-iyRFFnVJ1nimXtoXqrFQnSI5wi0\"",
		"mtime": "2026-08-14T18:51:49.940Z",
		"size": 107743,
		"path": "../public/assets/styles-BU2rh9c_.css"
	},
	"/assets/hero-BodF9zs-.jpg": {
		"type": "image/jpeg",
		"etag": "\"317e3-fDsWi4udLc2/oh4Hp5+WcEfB+14\"",
		"mtime": "2026-08-14T18:51:49.936Z",
		"size": 202723,
		"path": "../public/assets/hero-BodF9zs-.jpg"
	},
	"/assets/blog-frotas-GwhS-UMB.jpg": {
		"type": "image/jpeg",
		"etag": "\"d775d-h2AujwMxn/Urx76w7fjE45wdkpo\"",
		"mtime": "2026-08-14T18:51:49.928Z",
		"size": 882525,
		"path": "../public/assets/blog-frotas-GwhS-UMB.jpg"
	},
	"/assets/blog-caminhao-7xsPK6AY.jpg": {
		"type": "image/jpeg",
		"etag": "\"c060a-TleJu0aQvaWgXgSrMmtNETfSwXM\"",
		"mtime": "2026-08-14T18:51:49.923Z",
		"size": 787978,
		"path": "../public/assets/blog-caminhao-7xsPK6AY.jpg"
	},
	"/assets/lifema-logo-DNyZB3IQ.png": {
		"type": "image/png",
		"etag": "\"4eaba-4igV8nSLND33XL6hjmFlheAqMu0\"",
		"mtime": "2026-08-14T18:51:49.938Z",
		"size": 322234,
		"path": "../public/assets/lifema-logo-DNyZB3IQ.png"
	},
	"/assets/blog-saude-B4fmLAkX.jpg": {
		"type": "image/jpeg",
		"etag": "\"b3d7e-9KPBct+a8Lc0FeKnXgR/69DRXes\"",
		"mtime": "2026-08-14T18:51:49.933Z",
		"size": 736638,
		"path": "../public/assets/blog-saude-B4fmLAkX.jpg"
	},
	"/assets/blog-moto-BfykZcS7.jpg": {
		"type": "image/jpeg",
		"etag": "\"eebc1-jLsZVcS9t7efyUDS+iVKyVbUvMw\"",
		"mtime": "2026-08-14T18:51:49.930Z",
		"size": 977857,
		"path": "../public/assets/blog-moto-BfykZcS7.jpg"
	},
	"/assets/blog-viagem-BZ0T87nl.jpg": {
		"type": "image/jpeg",
		"etag": "\"c9130-5U4JiBrfvUexBZpICLiD/JNmUPE\"",
		"mtime": "2026-08-14T18:51:49.934Z",
		"size": 823600,
		"path": "../public/assets/blog-viagem-BZ0T87nl.jpg"
	}
};
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_zIyKJB = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_zIyKJB
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
[].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new FastResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function useNitroHooks() {
	const nitroApp = useNitroApp();
	const hooks = nitroApp.hooks;
	if (hooks) return hooks;
	return nitroApp.hooks = new HookableCore();
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/_module-handler.mjs
function createHandler(hooks) {
	const nitroApp = useNitroApp();
	const nitroHooks = useNitroHooks();
	return {
		async fetch(request, env, context) {
			globalThis.__env__ = env;
			augmentReq(request, {
				env,
				context
			});
			const ctxExt = {};
			const url = new URL(request.url);
			if (hooks.fetch) {
				const res = await hooks.fetch(request, env, context, url, ctxExt);
				if (res) return res;
			}
			return await nitroApp.fetch(request);
		},
		scheduled(controller, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:scheduled", {
				controller,
				env,
				context
			}) || Promise.resolve());
		},
		email(message, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:email", {
				message,
				event: message,
				env,
				context
			}) || Promise.resolve());
		},
		queue(batch, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:queue", {
				batch,
				event: batch,
				env,
				context
			}) || Promise.resolve());
		},
		tail(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:tail", {
				traces,
				env,
				context
			}) || Promise.resolve());
		},
		trace(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:trace", {
				traces,
				env,
				context
			}) || Promise.resolve());
		}
	};
}
function augmentReq(cfReq, ctx) {
	const req = cfReq;
	req.ip = cfReq.headers.get("cf-connecting-ip") || void 0;
	req.runtime ??= { name: "cloudflare" };
	req.runtime.cloudflare = {
		...req.runtime.cloudflare,
		...ctx
	};
	req.waitUntil = ctx.context?.waitUntil.bind(ctx.context);
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/cloudflare-module.mjs
var cloudflare_module_default = createHandler({ fetch(cfRequest, env, context, url) {
	if (env.ASSETS && isPublicAssetURL(url.pathname)) return env.ASSETS.fetch(cfRequest);
} });
//#endregion
export { cloudflare_module_default as default };

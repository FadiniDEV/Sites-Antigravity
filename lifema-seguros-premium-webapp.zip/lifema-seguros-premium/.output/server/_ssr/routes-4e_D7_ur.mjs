import { n as __toESM } from "../_runtime.mjs";
import { n as blogPosts, t as COMPANY } from "./blogPosts-CUNdaIJl.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { A as CircleQuestionMark, B as Award, C as Heart, D as GitCompare, E as Handshake, F as Car, I as Calendar, L as Building2, M as CircleCheckBig, N as ChevronRight, P as ChevronDown, S as House, T as Headphones, V as ArrowRight, a as Truck, b as LoaderCircle, c as SlidersHorizontal, d as Send, g as MessageCircle, h as Phone, i as UserCheck, l as Shield, m as Plane, n as Users, o as Stethoscope, p as Quote, s as Star, v as MapPin, w as HeartPulse, y as Mail, z as Bike } from "../_libs/lucide-react.mjs";
import { a as cn, i as TermsModal, n as Header, r as PrivacyModal, t as Footer } from "./TermsModal-Bfn12m1N.mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-4e_D7_ur.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var hero_default = "/assets/hero-BodF9zs-.jpg";
var highlights = [
	{
		icon: Handshake,
		label: "Atendimento Personalizado"
	},
	{
		icon: Shield,
		label: "Soluções Sob Medida"
	},
	{
		icon: Heart,
		label: "Proteção para diferentes momentos"
	}
];
function Hero() {
	const [offset, setOffset] = (0, import_react.useState)(0);
	const rafRef = (0, import_react.useRef)(void 0);
	(0, import_react.useEffect)(() => {
		const onScroll = () => {
			if (rafRef.current) return;
			rafRef.current = requestAnimationFrame(() => {
				setOffset(window.scrollY * .25);
				rafRef.current = void 0;
			});
		};
		window.addEventListener("scroll", onScroll, { passive: true });
		return () => window.removeEventListener("scroll", onScroll);
	}, []);
	const handleAnchor = (id) => {
		const el = document.getElementById(id);
		if (el) {
			const top = el.getBoundingClientRect().top + window.scrollY - 88;
			window.scrollTo({
				top,
				behavior: "smooth"
			});
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "inicio",
		className: "relative min-h-[85vh] lg:min-h-screen overflow-hidden pt-24 sm:pt-28 md:pt-32",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-0 scale-110",
				style: { transform: `translateY(${offset}px) scale(1.1)` },
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: hero_default,
					alt: "Família protegida em frente à casa",
					className: "h-full w-full object-cover",
					width: 1920,
					height: 1080,
					fetchPriority: "high"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-r from-navy via-navy/90 to-navy/70" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-navy via-transparent to-navy/40" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -right-40 top-1/4 h-[500px] w-[500px] rounded-full bg-gold/10 blur-[120px]" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mx-auto flex max-w-7xl min-h-[calc(100vh-6rem)] lg:min-h-[calc(100vh-7rem)] flex-col justify-center px-4 py-12 sm:py-16 md:py-20 lg:py-24",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-w-3xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "mb-3 sm:mb-4 inline-flex items-center gap-2 rounded-full border border-gold/30 bg-gold/10 px-3.5 py-1 sm:px-4 sm:py-1.5 text-xs sm:text-sm font-medium text-gold",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-1.5 w-1.5 rounded-full bg-gold" }), "Corretora de Seguros"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
							className: "font-display text-3xl font-extrabold leading-[1.15] text-cream sm:text-4xl md:text-5xl lg:text-6xl xl:text-7xl text-balance",
							children: [
								"Proteção para o que",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-gold",
									children: "realmente importa"
								}),
								"."
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 sm:mt-6 max-w-2xl text-base sm:text-lg md:text-xl leading-relaxed text-slate",
							children: "Na Lifema Seguros, encontramos soluções para proteger seu patrimônio, sua família, seu veículo e sua empresa com a orientação que você precisa."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6 sm:mt-8 flex flex-col sm:flex-row items-stretch sm:items-center gap-3 sm:gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: () => handleAnchor("contato"),
								className: "group inline-flex w-full sm:w-auto items-center justify-center gap-2 rounded-lg bg-gold px-6 sm:px-7 py-3 sm:py-3.5 text-sm sm:text-base font-semibold text-navy shadow-lg shadow-gold/25 transition-all hover:bg-gold-light hover:shadow-gold/40",
								children: ["Solicitar Cotação", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-5 w-5 transition-transform group-hover:translate-x-1" })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => handleAnchor("seguros"),
								className: "inline-flex w-full sm:w-auto items-center justify-center rounded-lg border border-cream/20 bg-cream/5 px-6 sm:px-7 py-3 sm:py-3.5 text-sm sm:text-base font-semibold text-cream backdrop-blur-sm transition-colors hover:bg-cream/10",
								children: "Conheça nossos Seguros"
							})]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-10 sm:mt-12 md:mt-16 grid gap-3 sm:gap-4 grid-cols-1 sm:grid-cols-3 lg:max-w-4xl",
					children: highlights.map((item, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: cn("flex items-center gap-3.5 sm:gap-4 rounded-xl border border-white/10 bg-navy-light/60 p-3.5 sm:p-4 lg:p-5 backdrop-blur-md transition-all hover:border-gold/30 hover:bg-navy-light", i === 0 && "animate-fade-in"),
						style: { animationDelay: `${i * 120}ms` },
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid h-10 w-10 sm:h-11 sm:w-11 shrink-0 place-items-center rounded-lg bg-gold/10 text-gold",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, { className: "h-5 w-5" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs sm:text-sm lg:text-base font-semibold text-cream",
							children: item.label
						})]
					}, item.label))
				})]
			})
		]
	});
}
function useReveal(threshold = .15) {
	const ref = (0, import_react.useRef)(null);
	const [visible, setVisible] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const el = ref.current;
		if (!el) return;
		const observer = new IntersectionObserver((entries) => {
			if (entries[0]?.isIntersecting) {
				setVisible(true);
				observer.unobserve(el);
			}
		}, {
			threshold,
			rootMargin: "0px 0px -50px 0px"
		});
		observer.observe(el);
		return () => observer.disconnect();
	}, [threshold]);
	return {
		ref,
		visible
	};
}
var about_default = "/assets/about-CyJqJ72t.jpg";
var stats = [
	{
		value: "+10",
		label: "anos de experiência"
	},
	{
		value: "+5k",
		label: "clientes atendidos"
	},
	{
		value: "+20",
		label: "seguradoras parceiras"
	}
];
function About() {
	const { ref, visible } = useReveal();
	const handleAnchor = (id) => {
		const el = document.getElementById(id);
		if (el) {
			const top = el.getBoundingClientRect().top + window.scrollY - 88;
			window.scrollTo({
				top,
				behavior: "smooth"
			});
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "sobre",
		ref,
		className: "relative overflow-hidden section-padding",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -left-40 top-20 h-[400px] w-[400px] rounded-full bg-gold/5 blur-[100px]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "relative mx-auto max-w-7xl px-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid items-center gap-10 md:gap-14 lg:grid-cols-2 lg:gap-16 xl:gap-20",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: cn("relative order-2 lg:order-1 reveal", visible && "reveal-visible"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative overflow-hidden rounded-2xl border border-white/10 shadow-2xl shadow-black/30",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: about_default,
							alt: "Consultoria de seguros Lifema",
							className: "h-[320px] sm:h-[420px] md:h-[480px] lg:h-[540px] xl:h-[600px] w-full object-cover",
							width: 800,
							height: 1e3,
							loading: "lazy"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-navy/60 via-transparent to-transparent" })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "absolute -bottom-4 right-2 sm:-bottom-6 sm:-right-4 lg:-right-6 max-w-[230px] sm:max-w-[280px] lg:max-w-xs rounded-xl border border-gold/20 bg-navy-light p-4 sm:p-5 shadow-xl shadow-black/30",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-2 sm:mb-3 flex items-center gap-2.5 sm:gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid h-8 w-8 sm:h-10 sm:w-10 place-items-center rounded-full bg-gold/10 text-gold",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Award, { className: "h-4 w-4 sm:h-5 sm:w-5" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-display text-sm sm:text-base lg:text-lg font-bold text-cream",
								children: "Experiência que protege"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs sm:text-sm text-slate leading-relaxed",
							children: "Mais de uma década conectando pessoas e empresas às melhores soluções de seguros."
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: cn("order-1 lg:order-2 reveal", visible && "reveal-visible"),
					style: { transitionDelay: "150ms" },
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mb-3 inline-block text-xs sm:text-sm font-semibold uppercase tracking-wider text-gold",
							children: "Sobre Nós"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
							className: "font-display text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold leading-tight text-cream text-balance",
							children: [
								"Seguro certo começa com",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-gold",
									children: "orientação certa"
								}),
								"."
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 sm:mt-6 text-base sm:text-lg leading-relaxed text-slate",
							children: "A Lifema Seguros auxilia clientes na busca por soluções de proteção adequadas às suas necessidades. Com uma equipe experiente e acesso a diversas seguradoras, nosso trabalho é simplificar escolhas importantes."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 sm:mt-4 text-sm sm:text-base leading-relaxed text-slate/80",
							children: "Entendemos que cada pessoa, família e empresa enfrenta riscos diferentes. Por isso, oferecemos atendimento personalizado e opções sob medida, para que você contrate com clareza e segurança."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-6 sm:mt-8 grid grid-cols-3 gap-2 sm:gap-4 border-y border-white/10 py-4 sm:py-6",
							children: stats.map((stat) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-center",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-display text-xl sm:text-2xl lg:text-3xl font-bold text-gold",
									children: stat.value
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-1 text-[11px] sm:text-xs lg:text-sm text-slate",
									children: stat.label
								})]
							}, stat.label))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => handleAnchor("contato"),
							className: "group mt-6 sm:mt-8 inline-flex w-full sm:w-auto items-center justify-center gap-2 rounded-lg bg-gold px-6 py-3 text-sm font-semibold text-navy transition-colors hover:bg-gold-light",
							children: ["Conheça a Lifema", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-4 w-4 transition-transform group-hover:translate-x-1" })]
						})
					]
				})]
			})
		})]
	});
}
function InsuranceCard({ icon: Icon, title, description, slug, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("group relative flex flex-col justify-between overflow-hidden rounded-2xl border border-white/10 bg-navy-light p-5 sm:p-6 lg:p-7 transition-all duration-300 hover:-translate-y-1 hover:border-gold/30 hover:shadow-xl hover:shadow-gold/5", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-4 sm:mb-5 flex h-12 w-12 sm:h-14 sm:w-14 items-center justify-center rounded-xl bg-gradient-to-br from-gold/20 to-gold/5 text-gold transition-transform duration-300 group-hover:scale-110",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-6 w-6 sm:h-7 sm:w-7" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-display text-lg sm:text-xl font-bold text-cream",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2.5 sm:mt-3 text-xs sm:text-sm leading-relaxed text-slate",
				children: description
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: "/blog/$slug",
			params: { slug },
			className: "mt-4 sm:mt-6 inline-flex items-center gap-1.5 self-start text-xs sm:text-sm font-semibold text-gold transition-colors hover:text-gold-light",
			children: ["Saiba mais", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "transition-transform group-hover:translate-x-1",
				children: "→"
			})]
		})]
	});
}
var insurances = [
	{
		icon: Car,
		title: "Seguro Auto",
		description: "Proteção completa para carros, com coberturas que se adaptam ao seu perfil.",
		slug: "como-escolher-um-seguro-auto-ideal-para-o-seu-perfil"
	},
	{
		icon: House,
		title: "Seguro Residencial",
		description: "Cobertura para sua casa e bens contra roubo, incêndio, danos e responsabilidade civil.",
		slug: "seguro-residencial-o-que-cobre-e-como-contratar"
	},
	{
		icon: HeartPulse,
		title: "Seguro de Vida",
		description: "Tranquilidade para você e segurança financeira para quem você ama.",
		slug: "seguro-de-vida-quando-e-por-que-fazer"
	},
	{
		icon: Building2,
		title: "Seguro Empresarial",
		description: "Soluções para proteger seu negócio, patrimônio e operação.",
		slug: "seguro-empresarial-proteja-seu-negocio-desde-o-inicio"
	},
	{
		icon: Stethoscope,
		title: "Seguro Saúde",
		description: "Planos de saúde individual, familiar ou empresarial com as melhores opções.",
		slug: "seguro-saude-como-escolher-o-melhor-plano-para-voce-e-sua-empresa"
	},
	{
		icon: Plane,
		title: "Seguro Viagem",
		description: "Viaje com segurança, com cobertura médica, bagagem e assistência 24h.",
		slug: "seguro-viagem-por-que-e-indispensavel-nas-suas-ferias-ou-trabalho"
	},
	{
		icon: Bike,
		title: "Seguro Moto",
		description: "Proteção para motocicletas, com coberturas para roubo, furto e acidentes.",
		slug: "seguro-moto-tudo-o-que-voce-precisa-saber-para-proteger-sua-motocicleta"
	},
	{
		icon: Truck,
		title: "Seguro Caminhão",
		description: "Cobertura especializada para veículos de carga e transporte.",
		slug: "seguro-caminhao-protecao-completa-para-veiculos-pesados-e-cargas"
	},
	{
		icon: Users,
		title: "Seguro para Frotas",
		description: "Gestão de risco e proteção para frotas de veículos empresariais.",
		slug: "seguro-para-frotas-como-reduzir-custos-e-proteger-os-veiculos-da-empresa"
	}
];
function InsuranceGrid() {
	const { ref, visible } = useReveal();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "seguros",
		ref,
		className: "relative section-padding bg-navy-light/30",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: cn("mx-auto max-w-3xl text-center reveal", visible && "reveal-visible"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mb-2 sm:mb-3 inline-block text-xs sm:text-sm font-semibold uppercase tracking-wider text-gold",
						children: "Nossos Seguros"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold leading-tight text-cream text-balance",
						children: "Proteção para cada necessidade"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 sm:mt-4 text-sm sm:text-base md:text-lg text-slate",
						children: "Escolha a cobertura ideal e conte com nossa orientação para encontrar a melhor alternativa."
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8 sm:mt-10 md:mt-14 grid gap-4 sm:gap-5 lg:gap-6 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3",
				children: insurances.map((item, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: cn("reveal", visible && "reveal-visible"),
					style: { transitionDelay: `${i * 80}ms` },
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InsuranceCard, { ...item })
				}, item.title))
			})]
		})
	});
}
var benefits = [
	{
		icon: UserCheck,
		title: "Atendimento Personalizado",
		description: "Entendemos seu perfil e suas necessidades antes de sugerir qualquer solução."
	},
	{
		icon: SlidersHorizontal,
		title: "Soluções Sob Medida",
		description: "Buscamos alternativas adequadas para cada cliente, sem soluções genéricas."
	},
	{
		icon: GitCompare,
		title: "Diversas Opções",
		description: "Compare possibilidades entre diferentes seguradoras antes de tomar sua decisão."
	},
	{
		icon: Headphones,
		title: "Acompanhamento",
		description: "Suporte durante toda a sua jornada com o seguro, desde a cotação até a renovação."
	}
];
function Benefits() {
	const { ref, visible } = useReveal();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "beneficios",
		ref,
		className: "relative overflow-hidden section-padding",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute right-0 top-1/2 h-[400px] w-[400px] -translate-y-1/2 translate-x-1/2 rounded-full bg-gold/5 blur-[100px]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "relative mx-auto max-w-7xl px-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-8 md:gap-12 lg:grid-cols-2 lg:gap-16 xl:gap-20 items-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: cn("reveal", visible && "reveal-visible"),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mb-2 sm:mb-3 inline-block text-xs sm:text-sm font-semibold uppercase tracking-wider text-gold",
							children: "Diferenciais"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
							className: "font-display text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold leading-tight text-cream text-balance",
							children: [
								"Por que escolher a ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-gold",
									children: "Lifema"
								}),
								"?"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 sm:mt-6 text-base sm:text-lg leading-relaxed text-slate",
							children: "Nossa prioridade é oferecer clareza, transparência e opções reais para que você se sinta seguro em cada decisão."
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-4 sm:gap-5 grid-cols-1 sm:grid-cols-2",
					children: benefits.map((item, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: cn("rounded-2xl border border-white/10 bg-navy-light p-5 sm:p-6 transition-all duration-300 hover:-translate-y-1 hover:border-gold/30 hover:shadow-xl hover:shadow-gold/5 reveal", visible && "reveal-visible"),
						style: { transitionDelay: `${i * 100}ms` },
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mb-3 sm:mb-4 flex h-11 w-11 sm:h-12 sm:w-12 items-center justify-center rounded-lg bg-gold/10 text-gold",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, { className: "h-5 w-5 sm:h-6 sm:w-6" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-display text-base sm:text-lg font-bold text-cream",
								children: item.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-xs sm:text-sm leading-relaxed text-slate",
								children: item.description
							})
						]
					}, item.title))
				})]
			})
		})]
	});
}
var steps = [
	{
		number: "01",
		title: "Conte o que você precisa",
		description: "Entramos em contato para entender seu perfil, seus bens e suas prioridades."
	},
	{
		number: "02",
		title: "Analisamos seu perfil",
		description: "Avaliamos riscos, coberturas necessárias e o melhor momento para contratar."
	},
	{
		number: "03",
		title: "Apresentamos as opções",
		description: "Você recebe uma comparação clara entre seguradoras e coberturas."
	},
	{
		number: "04",
		title: "Você escolhe com segurança",
		description: "Com a nossa orientação, você contrata o seguro ideal com confiança."
	}
];
function ProcessSteps() {
	const { ref, visible } = useReveal();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		ref,
		className: "relative section-padding bg-navy-light/30",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: cn("mb-10 sm:mb-14 text-center reveal", visible && "reveal-visible"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mb-2 sm:mb-3 inline-block text-xs sm:text-sm font-semibold uppercase tracking-wider text-gold",
					children: "Como Funciona"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold leading-tight text-cream text-balance",
					children: "Simplificamos a contratação do seu seguro"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative grid gap-6 sm:gap-8 grid-cols-1 sm:grid-cols-2 lg:grid-cols-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute left-10 right-10 top-7 hidden h-0.5 bg-gradient-to-r from-gold/20 via-gold/50 to-gold/20 lg:block" }), steps.map((step, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: cn("relative reveal", visible && "reveal-visible"),
					style: { transitionDelay: `${i * 120}ms` },
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "relative z-10 mx-auto mb-4 sm:mb-6 flex h-12 w-12 sm:h-14 sm:w-14 items-center justify-center rounded-full border-2 border-gold bg-navy shadow-lg shadow-gold/10",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-display text-xs sm:text-sm font-bold text-gold",
								children: step.number
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-display text-center text-base sm:text-lg font-bold text-cream",
							children: step.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-center text-xs sm:text-sm leading-relaxed text-slate",
							children: step.description
						})
					]
				}, step.number))]
			})]
		})
	});
}
function CtaBand() {
	const handleAnchor = (id) => {
		const el = document.getElementById(id);
		if (el) {
			const top = el.getBoundingClientRect().top + window.scrollY - 88;
			window.scrollTo({
				top,
				behavior: "smooth"
			});
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative overflow-hidden bg-gradient-to-r from-navy via-navy-light to-navy py-12 sm:py-16 md:py-20",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-[radial-gradient(circle_at_top_right,_var(--tw-gradient-stops))] from-gold/10 to-transparent" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative mx-auto flex max-w-7xl flex-col items-center justify-between gap-6 px-4 sm:flex-row",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "text-center sm:text-left",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "mb-2 inline-flex items-center gap-2 text-xs sm:text-sm font-semibold text-gold",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "h-4 w-4" }), "Fale com um corretor"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl sm:text-3xl lg:text-4xl font-bold text-cream text-balance",
					children: "Proteja hoje o que importa amanhã."
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				onClick: () => handleAnchor("contato"),
				className: "group inline-flex w-full sm:w-auto items-center justify-center gap-2 rounded-lg bg-gold px-6 sm:px-7 py-3 sm:py-3.5 text-sm sm:text-base font-semibold text-navy shadow-lg shadow-gold/25 transition-all hover:bg-gold-light hover:shadow-gold/40 shrink-0",
				children: ["Solicitar Cotação", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-5 w-5 transition-transform group-hover:translate-x-1" })]
			})]
		})]
	});
}
var testimonials = [
	{
		name: "Mariana Vasconcelos",
		role: "Seguro Residencial — Campinas / SP",
		text: "Atendimento claro e extremamente atencioso. Me ajudaram a entender cada detalhe da apólice e a escolher a melhor proteção para a nossa casa com ótimo custo-benefício."
	},
	{
		name: "Carlos Eduardo Mendes",
		role: "Diretor Comercial — Seguro Empresarial",
		text: "A Lifema Seguros nos apresentou opções completas para a nossa empresa e cuidou de toda a burocracia. O suporte e a agilidade deles fazem toda a diferença no dia a dia."
	},
	{
		name: "Rodrigo Silveira",
		role: "Seguro Auto & Frota",
		text: "Consegui uma cotação justa e com cobertura completa para os veículos. Quando precisei de assistência para guincho, o retorno foi rápido e sem complicações."
	}
];
function Testimonials() {
	const { ref, visible } = useReveal();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		ref,
		className: "relative overflow-hidden section-padding",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -left-40 bottom-0 h-[400px] w-[400px] rounded-full bg-gold/5 blur-[100px]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative mx-auto max-w-7xl px-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: cn("mb-10 sm:mb-14 text-center reveal", visible && "reveal-visible"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mb-2 sm:mb-3 inline-block text-xs sm:text-sm font-semibold uppercase tracking-wider text-gold",
						children: "Depoimentos"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold leading-tight text-cream text-balance",
						children: "O que dizem sobre nós"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 sm:mt-4 text-xs sm:text-sm text-slate",
						children: "A tranquilidade e a confiança de quem conta com a nossa assessoria."
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-5 sm:gap-6 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3",
				children: testimonials.map((item, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: cn("relative rounded-2xl border border-white/10 bg-navy-light p-5 sm:p-6 lg:p-7 transition-all duration-300 hover:border-gold/30 hover:shadow-xl hover:shadow-gold/5 reveal", visible && "reveal-visible"),
					style: { transitionDelay: `${i * 120}ms` },
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Quote, { className: "absolute right-5 top-5 sm:right-6 sm:top-6 h-8 w-8 sm:h-10 sm:w-10 text-gold/10" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mb-3 sm:mb-4 flex gap-1",
							children: [...Array(5)].map((_, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: "h-3.5 w-3.5 sm:h-4 sm:w-4 fill-gold text-gold" }, idx))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "relative z-10 text-sm sm:text-base leading-relaxed text-cream/90",
							children: [
								"\"",
								item.text,
								"\""
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-5 sm:mt-6 border-t border-white/10 pt-4 sm:pt-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-display text-sm sm:text-base font-semibold text-cream",
								children: item.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs sm:text-sm text-gold",
								children: item.role
							})]
						})
					]
				}, i))
			})]
		})]
	});
}
function BlogCards() {
	const { ref, visible } = useReveal();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "blog",
		ref,
		className: "relative overflow-hidden section-padding bg-navy-light/30",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: cn("mb-10 sm:mb-14 text-center reveal", visible && "reveal-visible"),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mb-2 sm:mb-3 inline-block text-xs sm:text-sm font-semibold uppercase tracking-wider text-gold",
							children: "Blog"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold leading-tight text-cream text-balance",
							children: "Informação também é proteção"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 sm:mt-4 text-xs sm:text-sm md:text-base text-slate",
							children: "Confira nossos conteúdos mais recentes sobre seguros e planejamento financeiro."
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-5 sm:gap-6 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3",
					children: blogPosts.slice(0, 3).map((post, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: cn("group flex flex-col justify-between overflow-hidden rounded-2xl border border-white/10 bg-navy-light transition-all duration-300 hover:-translate-y-1 hover:border-gold/30 hover:shadow-xl hover:shadow-gold/5 reveal", visible && "reveal-visible"),
						style: { transitionDelay: `${i * 100}ms` },
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative h-44 sm:h-48 lg:h-52 overflow-hidden",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: post.image,
									alt: post.title,
									className: "h-full w-full object-cover transition-transform duration-500 group-hover:scale-105",
									loading: "lazy"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-navy-light/80 to-transparent" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "absolute left-3.5 top-3.5 sm:left-4 sm:top-4 rounded-full bg-gold px-2.5 py-0.5 sm:px-3 sm:py-1 text-[11px] sm:text-xs font-semibold text-navy",
									children: post.category
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-5 sm:p-6",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mb-2.5 sm:mb-3 flex items-center gap-2 text-xs text-slate",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "h-3.5 w-3.5 text-gold" }), post.date]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-display text-base sm:text-lg font-bold leading-snug text-cream transition-colors group-hover:text-gold",
									children: post.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 line-clamp-2 text-xs sm:text-sm text-slate",
									children: post.excerpt
								})
							]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "p-5 pt-0 sm:p-6 sm:pt-0",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/blog/$slug",
								params: { slug: post.slug },
								className: "inline-flex items-center gap-1.5 text-xs sm:text-sm font-semibold text-gold transition-colors group-hover:text-gold-light",
								children: ["Ler artigo", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-4 w-4 transition-transform group-hover:translate-x-1" })]
							})
						})]
					}, post.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-8 sm:mt-12 text-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/blog",
						className: "inline-flex w-full sm:w-auto items-center justify-center gap-2 rounded-lg border border-gold/40 bg-gold/10 px-6 py-3 text-sm font-semibold text-gold transition-all hover:bg-gold hover:text-navy",
						children: ["Ver Todos os Artigos no Blog", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-4 w-4" })]
					})
				})
			]
		})
	});
}
var faqs = [
	{
		question: "O que faz uma corretora de seguros?",
		answer: "A corretora atua como intermediária entre o cliente e as seguradoras. Nossa função é entender suas necessidades, apresentar opções compatíveis, esclarecer coberturas e acompanhar a contratação e eventuais sinistros."
	},
	{
		question: "Como solicitar uma cotação?",
		answer: "Você pode clicar no botão 'Cotação de Seguros' no menu ou preencher o formulário de contato. Entraremos em contato para entender seu perfil e enviar as melhores opções."
	},
	{
		question: "Quais tipos de seguros a Lifema oferece?",
		answer: "Trabalhamos com seguro auto, residencial, vida, empresarial, saúde, viagem, moto, caminhão e frotas. Também podemos estudar outras necessidades específicas."
	},
	{
		question: "A contratação é feita diretamente com a seguradora?",
		answer: "A apólice é emitida pela seguradora escolhida, mas a Lifema acompanha todo o processo, tirando dúvidas e ajudando na escolha da cobertura mais adequada."
	},
	{
		question: "Como funciona o atendimento em caso de sinistro?",
		answer: "Orientamos nossos clientes sobre o canal correto de acionamento da seguradora e, quando necessário, acompanhamos a comunicação para facilitar a resolução."
	}
];
function FAQ() {
	const { ref, visible } = useReveal();
	const [openIndex, setOpenIndex] = (0, import_react.useState)(0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		ref,
		className: "relative overflow-hidden section-padding",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute right-0 top-0 h-[400px] w-[400px] translate-x-1/2 rounded-full bg-gold/5 blur-[100px]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative mx-auto max-w-4xl px-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: cn("mb-10 sm:mb-14 text-center reveal", visible && "reveal-visible"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mb-2 sm:mb-3 inline-block text-xs sm:text-sm font-semibold uppercase tracking-wider text-gold",
					children: "Dúvidas"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold leading-tight text-cream text-balance",
					children: "Perguntas Frequentes"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-3 sm:space-y-4",
				children: faqs.map((faq, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: cn("overflow-hidden rounded-2xl border border-white/10 bg-navy-light transition-all reveal", visible && "reveal-visible", openIndex === i && "border-gold/30"),
					style: { transitionDelay: `${i * 80}ms` },
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => setOpenIndex(openIndex === i ? null : i),
						className: "flex w-full items-center justify-between gap-3 px-4 py-4 sm:px-6 sm:py-5 text-left",
						"aria-expanded": openIndex === i,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center gap-2.5 sm:gap-3 font-display text-sm sm:text-base font-semibold text-cream",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleQuestionMark, { className: "h-4 w-4 sm:h-5 sm:w-5 shrink-0 text-gold" }), faq.question]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: cn("h-4 w-4 sm:h-5 sm:w-5 shrink-0 text-gold transition-transform duration-300", openIndex === i && "rotate-180") })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: cn("overflow-hidden px-4 sm:px-6 transition-all duration-300 ease-in-out", openIndex === i ? "max-h-96 pb-4 sm:pb-6" : "max-h-0"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "pl-6 sm:pl-8 text-xs sm:text-sm md:text-base leading-relaxed text-slate",
							children: faq.answer
						})
					})]
				}, i))
			})]
		})]
	});
}
var insuranceOptions = [
	"Seguro Auto",
	"Seguro Residencial",
	"Seguro de Vida",
	"Seguro Empresarial",
	"Seguro Saúde",
	"Seguro Viagem",
	"Seguro Moto",
	"Seguro Caminhão",
	"Seguro para Frotas",
	"Outro"
];
function Contact() {
	const { ref, visible } = useReveal();
	const [form, setForm] = (0, import_react.useState)({
		name: "",
		phone: "",
		email: "",
		type: "",
		message: ""
	});
	const [errors, setErrors] = (0, import_react.useState)({});
	const [isSubmitting, setIsSubmitting] = (0, import_react.useState)(false);
	const [submitted, setSubmitted] = (0, import_react.useState)(false);
	const validate = () => {
		const next = {};
		if (!form.name.trim()) next.name = "Informe seu nome";
		if (!form.phone.trim()) next.phone = "Informe seu telefone";
		if (!form.email.trim() || !/\S+@\S+\.\S+/.test(form.email)) next.email = "Informe um e-mail válido";
		if (!form.type) next.type = "Selecione um tipo de seguro";
		if (!form.message.trim()) next.message = "Escreva sua mensagem";
		setErrors(next);
		return Object.keys(next).length === 0;
	};
	const handleSubmit = async (e) => {
		e.preventDefault();
		if (!validate()) return;
		setIsSubmitting(true);
		try {
			await fetch(`https://formsubmit.co/ajax/${COMPANY.email}`, {
				method: "POST",
				headers: {
					"Content-Type": "application/json",
					Accept: "application/json"
				},
				body: JSON.stringify({
					_subject: `Nova Solicitação de Cotação — ${form.name}`,
					Nome: form.name.trim(),
					Telefone: form.phone.trim(),
					Email: form.email.trim(),
					"Tipo de Seguro": form.type,
					Mensagem: form.message.trim()
				})
			});
		} catch (err) {
			console.error("Erro ao enviar e-mail:", err);
		} finally {
			setIsSubmitting(false);
			setSubmitted(true);
			setTimeout(() => {
				setForm({
					name: "",
					phone: "",
					email: "",
					type: "",
					message: ""
				});
				setSubmitted(false);
			}, 5e3);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "contato",
		ref,
		className: "relative overflow-hidden section-padding bg-navy-light/30",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto max-w-7xl px-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-8 md:gap-12 lg:grid-cols-2 lg:gap-16 xl:gap-20 items-start",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: cn("reveal", visible && "reveal-visible"),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mb-2 sm:mb-3 inline-block text-xs sm:text-sm font-semibold uppercase tracking-wider text-gold",
							children: "Contato"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold leading-tight text-cream text-balance",
							children: "Solicite uma cotação"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 sm:mt-6 text-base sm:text-lg leading-relaxed text-slate",
							children: "Preencha o formulário e nossa equipe entrará em contato para apresentar as melhores opções para você."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6 sm:mt-8 space-y-3.5 sm:space-y-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactItem, {
									icon: MessageCircle,
									label: "WhatsApp",
									value: COMPANY.whatsapp,
									href: `https://wa.me/${COMPANY.whatsappNumber}?text=${encodeURIComponent(COMPANY.whatsappDefaultMessage)}`
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactItem, {
									icon: Phone,
									label: "Telefone",
									value: COMPANY.phone,
									href: `tel:${COMPANY.phoneRaw}`
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactItem, {
									icon: Mail,
									label: "E-mail",
									value: COMPANY.email,
									href: `mailto:${COMPANY.email}`
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactItem, {
									icon: MapPin,
									label: "Endereço",
									value: COMPANY.address,
									href: COMPANY.mapsUrl
								})
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("form", {
					onSubmit: handleSubmit,
					className: cn("rounded-2xl border border-white/10 bg-navy-light p-5 sm:p-7 md:p-8 shadow-xl shadow-black/10 reveal", visible && "reveal-visible"),
					style: { transitionDelay: "150ms" },
					children: submitted ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col items-center justify-center py-10 sm:py-12 text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mb-4 grid h-14 w-14 sm:h-16 sm:w-16 place-items-center rounded-full bg-gold/10 text-gold",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheckBig, { className: "h-7 w-7 sm:h-8 sm:w-8" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-display text-lg sm:text-xl font-bold text-cream",
								children: "Mensagem enviada!"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-xs sm:text-sm text-slate",
								children: "Agradecemos o contato. Retornaremos em breve."
							})
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-4 sm:gap-5 sm:grid-cols-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Nome",
									error: errors.name,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "text",
										value: form.name,
										onChange: (e) => setForm({
											...form,
											name: e.target.value
										}),
										placeholder: "Seu nome completo",
										className: "w-full rounded-lg border border-white/10 bg-navy px-3.5 sm:px-4 py-2.5 sm:py-3 text-sm text-cream outline-none transition-colors placeholder:text-slate/50 focus:border-gold"
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Telefone",
									error: errors.phone,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "tel",
										value: form.phone,
										onChange: (e) => setForm({
											...form,
											phone: e.target.value
										}),
										placeholder: "(00) 00000-0000",
										className: "w-full rounded-lg border border-white/10 bg-navy px-3.5 sm:px-4 py-2.5 sm:py-3 text-sm text-cream outline-none transition-colors placeholder:text-slate/50 focus:border-gold"
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "E-mail",
									error: errors.email,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "email",
										value: form.email,
										onChange: (e) => setForm({
											...form,
											email: e.target.value
										}),
										placeholder: "seu@email.com",
										className: "w-full rounded-lg border border-white/10 bg-navy px-3.5 sm:px-4 py-2.5 sm:py-3 text-sm text-cream outline-none transition-colors placeholder:text-slate/50 focus:border-gold"
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Tipo de Seguro",
									error: errors.type,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										value: form.type,
										onChange: (e) => setForm({
											...form,
											type: e.target.value
										}),
										className: "w-full rounded-lg border border-white/10 bg-navy px-3.5 sm:px-4 py-2.5 sm:py-3 text-sm text-cream outline-none transition-colors focus:border-gold",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "",
											disabled: true,
											children: "Selecione"
										}), insuranceOptions.map((opt) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: opt,
											children: opt
										}, opt))]
									})
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							className: "mt-4 sm:mt-5",
							label: "Mensagem",
							error: errors.message,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								value: form.message,
								onChange: (e) => setForm({
									...form,
									message: e.target.value
								}),
								placeholder: "Conte um pouco sobre o que você precisa...",
								rows: 4,
								className: "w-full rounded-lg border border-white/10 bg-navy px-3.5 sm:px-4 py-2.5 sm:py-3 text-sm text-cream outline-none transition-colors placeholder:text-slate/50 focus:border-gold"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "submit",
							disabled: isSubmitting,
							className: "group mt-5 sm:mt-6 inline-flex w-full sm:w-auto items-center justify-center gap-2 rounded-lg bg-gold px-6 py-3 sm:py-3.5 text-sm sm:text-base font-semibold text-navy transition-all hover:bg-gold-light disabled:opacity-70",
							children: isSubmitting ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }), "Enviando..."] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "h-4 w-4" }), "Solicitar Cotação"] })
						})
					] })
				})]
			})
		})
	});
}
function ContactItem({ icon: Icon, label, value, href }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-start gap-3 sm:gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid h-10 w-10 sm:h-11 sm:w-11 shrink-0 place-items-center rounded-lg bg-gold/10 text-gold",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-4 w-4 sm:h-5 sm:w-5" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0 flex-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-[11px] sm:text-xs font-semibold uppercase tracking-wider text-slate",
				children: label
			}), href ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href,
				target: href.startsWith("http") ? "_blank" : void 0,
				rel: href.startsWith("http") ? "noopener noreferrer" : void 0,
				className: "mt-0.5 block text-sm sm:text-base text-cream transition-colors hover:text-gold break-words",
				children: value
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-0.5 text-sm sm:text-base text-cream break-words",
				children: value
			})]
		})]
	});
}
function Field({ label, error, children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
				className: "mb-1 sm:mb-1.5 block text-xs sm:text-sm font-medium text-cream",
				children: label
			}),
			children,
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mt-1 block text-xs text-red-400",
				children: error
			})
		]
	});
}
function HomeComponent() {
	const [privacyOpen, setPrivacyOpen] = (0, import_react.useState)(false);
	const [termsOpen, setTermsOpen] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-navy text-cream overflow-x-hidden w-full max-w-full",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "overflow-x-hidden w-full max-w-full",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hero, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(About, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InsuranceGrid, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Benefits, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProcessSteps, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CtaBand, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Testimonials, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BlogCards, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FAQ, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Contact, {})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {
				onPrivacy: () => setPrivacyOpen(true),
				onTerms: () => setTermsOpen(true)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrivacyModal, {
				open: privacyOpen,
				onClose: () => setPrivacyOpen(false)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TermsModal, {
				open: termsOpen,
				onClose: () => setTermsOpen(false)
			})
		]
	});
}
//#endregion
export { HomeComponent as component };

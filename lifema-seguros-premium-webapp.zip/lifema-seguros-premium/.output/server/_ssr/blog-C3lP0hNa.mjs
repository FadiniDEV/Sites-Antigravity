import { n as __toESM } from "../_runtime.mjs";
import { n as blogPosts } from "./blogPosts-CUNdaIJl.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { I as Calendar, N as ChevronRight, R as BookOpen, V as ArrowRight, f as Search, k as Clock } from "../_libs/lucide-react.mjs";
import { a as cn, i as TermsModal, n as Header, r as PrivacyModal, t as Footer } from "./TermsModal-Bfn12m1N.mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/blog-C3lP0hNa.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var categories = [
	"Todos",
	"Seguro Auto",
	"Seguro Residencial",
	"Seguro de Vida",
	"Seguro Empresarial",
	"Seguro Saúde",
	"Seguro Viagem",
	"Seguro Moto",
	"Seguro Caminhão",
	"Seguro para Frotas",
	"Dicas"
];
function BlogListPage() {
	const [selectedCategory, setSelectedCategory] = (0, import_react.useState)("Todos");
	const [searchQuery, setSearchQuery] = (0, import_react.useState)("");
	const [privacyOpen, setPrivacyOpen] = (0, import_react.useState)(false);
	const [termsOpen, setTermsOpen] = (0, import_react.useState)(false);
	const filteredPosts = blogPosts.filter((post) => {
		const matchesCategory = selectedCategory === "Todos" || post.category === selectedCategory;
		const matchesSearch = post.title.toLowerCase().includes(searchQuery.toLowerCase()) || post.excerpt.toLowerCase().includes(searchQuery.toLowerCase()) || post.category.toLowerCase().includes(searchQuery.toLowerCase());
		return matchesCategory && matchesSearch;
	});
	const featuredPost = blogPosts[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-navy text-cream",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "pt-24 sm:pt-32",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "relative overflow-hidden border-b border-white/10 bg-gradient-to-b from-navy-light/60 to-navy py-12 sm:py-16 md:py-20 lg:py-24",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -left-40 top-10 h-96 w-96 rounded-full bg-gold/10 blur-[120px]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "relative mx-auto max-w-7xl px-4",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col items-center text-center",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "mb-3 sm:mb-4 inline-flex items-center gap-2 rounded-full border border-gold/30 bg-gold/10 px-3.5 py-1 sm:px-4 sm:py-1.5 text-xs font-semibold uppercase tracking-wider text-gold",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "h-4 w-4" }), "Blog & Conteúdo"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
										className: "font-display text-3xl font-extrabold leading-tight text-cream sm:text-4xl md:text-5xl lg:text-6xl text-balance",
										children: [
											"Informação que gera ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-gold",
												children: "proteção"
											}),
											"."
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-3 sm:mt-4 max-w-2xl text-base sm:text-lg md:text-xl text-slate",
										children: "Confira nossos artigos, guias e dicas práticas para tirar dúvidas sobre apólices, coberturas e cuidar do que é seu."
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-6 sm:mt-8 flex w-full max-w-lg items-center rounded-xl border border-white/15 bg-navy-light px-3.5 py-2.5 sm:px-4 sm:py-3 shadow-xl focus-within:border-gold/60",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "h-4 w-4 sm:h-5 sm:w-5 text-slate shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "text",
											value: searchQuery,
											onChange: (e) => setSearchQuery(e.target.value),
											placeholder: "Pesquisar por assunto, seguro ou palavra...",
											className: "ml-2.5 sm:ml-3 w-full bg-transparent text-xs sm:text-sm text-cream placeholder-slate/60 outline-none"
										})]
									})
								]
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						className: "border-b border-white/5 bg-navy/80 py-4 sm:py-6 sticky top-[72px] sm:top-[80px] z-30 backdrop-blur-md",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mx-auto max-w-7xl px-4",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex gap-2 overflow-x-auto no-scrollbar pb-1 sm:pb-0 sm:flex-wrap sm:justify-center",
								children: categories.map((cat) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => setSelectedCategory(cat),
									className: cn("whitespace-nowrap rounded-full px-3.5 py-1.5 sm:px-4 sm:py-2 text-xs sm:text-sm font-semibold transition-all shrink-0", selectedCategory === cat ? "bg-gold text-navy shadow-md shadow-gold/20" : "border border-white/10 bg-navy-light/50 text-cream/80 hover:border-gold/40 hover:text-cream"),
									children: cat
								}, cat))
							})
						})
					}),
					selectedCategory === "Todos" && !searchQuery && featuredPost && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						className: "py-8 sm:py-12 lg:py-16",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto max-w-7xl px-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mb-4 sm:mb-6 inline-block text-xs font-semibold uppercase tracking-wider text-gold",
								children: "★ Artigo em Destaque"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-6 sm:gap-8 overflow-hidden rounded-3xl border border-white/10 bg-navy-light lg:grid-cols-12 lg:gap-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative h-56 sm:h-72 lg:col-span-7 lg:h-full overflow-hidden",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
											src: featuredPost.image,
											alt: featuredPost.title,
											className: "h-full w-full object-cover transition-transform duration-700 hover:scale-105"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-navy-light via-transparent to-transparent lg:bg-gradient-to-r" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "absolute left-4 top-4 sm:left-6 sm:top-6 rounded-full bg-gold px-2.5 py-0.5 sm:px-3 sm:py-1 text-xs font-bold text-navy",
											children: featuredPost.category
										})
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-col justify-between p-5 sm:p-8 lg:p-10 lg:col-span-5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mb-3 sm:mb-4 flex items-center gap-3 sm:gap-4 text-xs text-slate",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "flex items-center gap-1.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "h-3.5 w-3.5 text-gold" }), featuredPost.date]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "flex items-center gap-1.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "h-3.5 w-3.5 text-gold" }), featuredPost.readTime]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
											className: "font-display text-xl sm:text-2xl lg:text-3xl font-bold leading-snug text-cream",
											children: featuredPost.title
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-3 sm:mt-4 text-xs sm:text-sm md:text-base leading-relaxed text-slate",
											children: featuredPost.excerpt
										})
									] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-6 sm:mt-8 flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-t border-white/10 pt-5 sm:pt-6",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs text-slate",
											children: featuredPost.author.name
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
											to: "/blog/$slug",
											params: { slug: featuredPost.slug },
											className: "inline-flex w-full sm:w-auto items-center justify-center gap-2 rounded-lg bg-gold px-4 sm:px-5 py-2 sm:py-2.5 text-xs sm:text-sm font-semibold text-navy transition-all hover:bg-gold-light",
											children: ["Ler artigo completo", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-4 w-4" })]
										})]
									})]
								})]
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						className: "py-8 sm:py-12 lg:py-16",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto max-w-7xl px-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-6 sm:mb-8 flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-display text-xl sm:text-2xl font-bold text-cream",
									children: selectedCategory === "Todos" ? "Todos os Artigos" : `Artigos em ${selectedCategory}`
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs text-slate",
									children: [
										filteredPosts.length,
										" artigo",
										filteredPosts.length === 1 ? "" : "s",
										" encontrado",
										filteredPosts.length === 1 ? "" : "s"
									]
								})]
							}), filteredPosts.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-2xl border border-white/10 bg-navy-light p-8 sm:p-12 text-center",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-base sm:text-lg text-slate",
									children: [
										"Nenhum artigo encontrado para a busca \"",
										searchQuery,
										"\"."
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => {
										setSelectedCategory("Todos");
										setSearchQuery("");
									},
									className: "mt-4 inline-flex items-center gap-2 text-sm font-semibold text-gold hover:underline",
									children: "Limpar filtros"
								})]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid gap-5 sm:gap-6 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3",
								children: filteredPosts.map((post) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
									className: "group flex flex-col justify-between overflow-hidden rounded-2xl border border-white/10 bg-navy-light transition-all duration-300 hover:-translate-y-1.5 hover:border-gold/40 hover:shadow-2xl hover:shadow-gold/10",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative h-44 sm:h-52 overflow-hidden",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
												src: post.image,
												alt: post.title,
												className: "h-full w-full object-cover transition-transform duration-500 group-hover:scale-105",
												loading: "lazy"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-navy-light/90 to-transparent" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "absolute left-3.5 top-3.5 sm:left-4 sm:top-4 rounded-full bg-gold px-2.5 py-0.5 sm:px-3 sm:py-1 text-xs font-semibold text-navy",
												children: post.category
											})
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-5 sm:p-6",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "mb-2.5 sm:mb-3 flex items-center gap-3 text-xs text-slate",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "flex items-center gap-1",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "h-3.5 w-3.5 text-gold" }), post.date]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "flex items-center gap-1",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "h-3.5 w-3.5 text-gold" }), post.readTime]
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
												className: "font-display text-lg sm:text-xl font-bold leading-snug text-cream transition-colors group-hover:text-gold",
												children: post.title
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-2.5 line-clamp-3 text-xs sm:text-sm leading-relaxed text-slate",
												children: post.excerpt
											})
										]
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "border-t border-white/5 p-5 pt-3.5 sm:p-6 sm:pt-4",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
											to: "/blog/$slug",
											params: { slug: post.slug },
											className: "inline-flex items-center gap-2 text-xs sm:text-sm font-semibold text-gold transition-colors hover:text-gold-light",
											children: ["Ler artigo completo", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-4 w-4 transition-transform group-hover:translate-x-1" })]
										})
									})]
								}, post.id))
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						className: "border-t border-white/10 bg-gradient-to-r from-navy via-navy-light to-navy py-12 sm:py-16",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto max-w-5xl px-4 text-center",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-display text-2xl sm:text-3xl md:text-4xl font-bold text-cream",
									children: "Ficou com alguma dúvida sobre o seu seguro?"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 sm:mt-4 text-sm sm:text-base md:text-lg text-slate",
									children: "Nossa equipe de especialistas está pronta para orientar você com as melhores cotações do mercado."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									href: "/#contato",
									className: "mt-6 sm:mt-8 inline-flex w-full sm:w-auto items-center justify-center gap-2 rounded-lg bg-gold px-6 sm:px-8 py-3.5 sm:py-4 text-sm sm:text-base font-semibold text-navy shadow-lg shadow-gold/20 transition-all hover:bg-gold-light",
									children: ["Solicitar Cotação Personalizada", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-5 w-5" })]
								})
							]
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {
				onPrivacy: () => setPrivacyOpen(true),
				onTerms: () => setTermsOpen(true)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrivacyModal, {
				open: privacyOpen,
				onClose: () => setPrivacyOpen(false)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TermsModal, {
				open: termsOpen,
				onClose: () => setTermsOpen(false)
			})
		]
	});
}
//#endregion
export { BlogListPage as component };

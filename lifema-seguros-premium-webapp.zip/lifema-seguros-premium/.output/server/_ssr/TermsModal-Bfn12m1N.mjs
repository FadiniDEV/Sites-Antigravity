import { n as __toESM } from "../_runtime.mjs";
import { t as COMPANY } from "./blogPosts-CUNdaIJl.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { O as Facebook, _ as Menu, h as Phone, t as X, v as MapPin, x as Instagram, y as Mail } from "../_libs/lucide-react.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/TermsModal-Bfn12m1N.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var lifema_logo_default = "/assets/lifema-logo-DNyZB3IQ.png";
var navItems = [
	{
		label: "Início",
		href: "/#inicio"
	},
	{
		label: "Sobre Nós",
		href: "/#sobre"
	},
	{
		label: "Seguros",
		href: "/#seguros"
	},
	{
		label: "Benefícios",
		href: "/#beneficios"
	},
	{
		label: "Blog",
		href: "/blog"
	},
	{
		label: "Contato",
		href: "/#contato"
	}
];
function Header() {
	const [scrolled, setScrolled] = (0, import_react.useState)(false);
	const [mobileOpen, setMobileOpen] = (0, import_react.useState)(false);
	const [activeSection, setActiveSection] = (0, import_react.useState)("inicio");
	(0, import_react.useEffect)(() => {
		const onScroll = () => setScrolled(window.scrollY > 40);
		window.addEventListener("scroll", onScroll, { passive: true });
		return () => window.removeEventListener("scroll", onScroll);
	}, []);
	(0, import_react.useEffect)(() => {
		if (typeof window === "undefined" || window.location.pathname !== "/") return;
		const observer = new IntersectionObserver((entries) => {
			entries.forEach((entry) => {
				if (entry.isIntersecting) setActiveSection(entry.target.id);
			});
		}, {
			rootMargin: "-40% 0px -50% 0px",
			threshold: .1
		});
		navItems.forEach(({ href }) => {
			if (!href.includes("#")) return;
			const id = href.split("#")[1];
			const el = document.getElementById(id);
			if (el) observer.observe(el);
		});
		return () => observer.disconnect();
	}, []);
	const handleAnchorClick = (href) => {
		setMobileOpen(false);
		if (href === "/blog") {
			window.location.href = "/blog";
			return;
		}
		const hash = href.includes("#") ? href.split("#")[1] : "";
		if (window.location.pathname !== "/") {
			window.location.href = `/#${hash}`;
			return;
		}
		const el = document.getElementById(hash);
		if (el) {
			const top = el.getBoundingClientRect().top + window.scrollY - 88;
			window.scrollTo({
				top,
				behavior: "smooth"
			});
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: cn("fixed inset-x-0 top-0 z-50 w-full transition-all duration-300", scrolled || mobileOpen ? "bg-navy/95 shadow-lg shadow-black/20 backdrop-blur-md" : "bg-gradient-to-b from-navy/90 to-transparent"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "hidden border-b border-white/5 bg-navy-light/60 md:block",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-7xl items-center justify-between px-4 py-1.5 text-xs text-slate",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-4 lg:gap-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: COMPANY.mapsUrl,
								target: "_blank",
								rel: "noopener noreferrer",
								className: "flex items-center gap-1.5 transition-colors hover:text-gold",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "h-3.5 w-3.5 shrink-0 text-gold" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "truncate max-w-[280px] lg:max-w-none",
									children: COMPANY.address
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: `tel:${COMPANY.phoneRaw}`,
								className: "flex items-center gap-1.5 transition-colors hover:text-gold",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "h-3.5 w-3.5 shrink-0 text-gold" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: COMPANY.phone })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: `mailto:${COMPANY.email}`,
								className: "flex items-center gap-1.5 transition-colors hover:text-gold",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "h-3.5 w-3.5 shrink-0 text-gold" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "hidden xl:inline",
										children: COMPANY.email
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "xl:hidden",
										children: "E-mail"
									})
								]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: COMPANY.social.instagram,
							target: "_blank",
							rel: "noopener noreferrer",
							className: "transition-colors hover:text-gold",
							children: "Instagram"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: COMPANY.social.facebook,
							target: "_blank",
							rel: "noopener noreferrer",
							className: "transition-colors hover:text-gold",
							children: "Facebook"
						})]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex w-full max-w-7xl items-center justify-between px-4 py-3 sm:py-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: "/",
						onClick: (e) => {
							if (window.location.pathname === "/") {
								e.preventDefault();
								handleAnchorClick("/#inicio");
							}
						},
						className: "flex items-center gap-2.5 sm:gap-3 shrink-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: lifema_logo_default,
							alt: COMPANY.name,
							className: "h-8 sm:h-10 lg:h-12 w-auto object-contain"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display text-sm font-bold text-cream sm:text-base lg:text-lg",
							children: COMPANY.name
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "hidden items-center gap-0.5 lg:flex xl:gap-1.5",
						children: navItems.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: item.href,
							onClick: (e) => {
								e.preventDefault();
								handleAnchorClick(item.href);
							},
							className: cn("relative px-2.5 py-2 text-xs font-medium transition-colors xl:px-4 xl:text-sm", activeSection === item.href.replace("#", "") ? "text-gold" : "text-cream/80 hover:text-cream"),
							children: [item.label, activeSection === item.href.replace("#", "") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute bottom-0 left-1/2 h-0.5 w-5 -translate-x-1/2 rounded-full bg-gold" })]
						}, item.href))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "hidden items-center gap-4 lg:flex",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "/#contato",
							onClick: (e) => {
								e.preventDefault();
								handleAnchorClick("/#contato");
							},
							className: "inline-flex items-center justify-center rounded-lg bg-gold px-4 py-2 text-xs font-semibold text-navy shadow-md shadow-gold/20 transition-all hover:bg-gold-light hover:shadow-gold/40 xl:px-5 xl:py-2.5 xl:text-sm",
							children: "Solicitar Cotação"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "inline-flex items-center justify-center rounded-lg p-2 text-cream lg:hidden focus:outline-none shrink-0",
						onClick: () => setMobileOpen(!mobileOpen),
						"aria-label": mobileOpen ? "Fechar menu" : "Abrir menu",
						children: mobileOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-6 w-6" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "h-6 w-6" })
					})
				]
			}),
			mobileOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 top-[56px] sm:top-[68px] z-30 bg-black/60 backdrop-blur-sm lg:hidden",
				onClick: () => setMobileOpen(false)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: cn("absolute inset-x-0 top-full z-40 max-h-[calc(100dvh-4.5rem)] overflow-y-auto border-t border-white/10 bg-navy-light/98 shadow-2xl transition-all duration-300 lg:hidden", mobileOpen ? "pointer-events-auto opacity-100 translate-y-0 visible" : "pointer-events-none opacity-0 -translate-y-2 invisible"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
					className: "flex flex-col px-4 py-4 space-y-1",
					children: [navItems.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: item.href,
						onClick: (e) => {
							e.preventDefault();
							handleAnchorClick(item.href);
						},
						className: cn("flex items-center min-h-[44px] rounded-lg px-3 py-2 text-base font-medium transition-colors border-b border-white/5", activeSection === item.href.replace("#", "") ? "text-gold bg-white/5" : "text-cream/80 hover:text-cream hover:bg-white/5"),
						children: item.label
					}, item.href)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "pt-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "/#contato",
							onClick: (e) => {
								e.preventDefault();
								handleAnchorClick("/#contato");
							},
							className: "inline-flex min-h-[44px] w-full items-center justify-center rounded-lg bg-gold px-4 py-3 text-sm font-semibold text-navy shadow-md shadow-gold/20",
							children: "Solicitar Cotação"
						})
					})]
				})
			})
		]
	});
}
var quickLinks = [
	{
		label: "Início",
		href: "#inicio"
	},
	{
		label: "Sobre Nós",
		href: "#sobre"
	},
	{
		label: "Seguros",
		href: "#seguros"
	},
	{
		label: "Benefícios",
		href: "#beneficios"
	},
	{
		label: "Blog",
		href: "#blog"
	},
	{
		label: "Contato",
		href: "#contato"
	}
];
var insuranceLinks = [
	"Seguro Auto",
	"Seguro Residencial",
	"Seguro de Vida",
	"Seguro Empresarial",
	"Seguro Saúde",
	"Seguro Viagem"
];
function Footer({ onPrivacy, onTerms }) {
	const handleAnchor = (href) => {
		const id = href.replace("#", "");
		const el = document.getElementById(id);
		if (el) {
			const top = el.getBoundingClientRect().top + window.scrollY - 88;
			window.scrollTo({
				top,
				behavior: "smooth"
			});
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		className: "relative overflow-hidden border-t border-white/10 bg-navy-light",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto max-w-7xl px-4 py-12 sm:py-16 lg:py-20",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-8 sm:gap-10 sm:grid-cols-2 lg:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "sm:col-span-2 lg:col-span-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: "#inicio",
								onClick: (e) => {
									e.preventDefault();
									handleAnchor("#inicio");
								},
								className: "inline-flex items-center gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: lifema_logo_default,
									alt: COMPANY.name,
									className: "h-10 sm:h-12 w-auto object-contain"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-display text-base sm:text-lg font-bold text-cream",
									children: COMPANY.name
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 sm:mt-4 max-w-xs text-xs sm:text-sm leading-relaxed text-slate",
								children: "Corretora de seguros brasileira dedicada a proteger pessoas, famílias e empresas com soluções personalizadas."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-5 sm:mt-6 flex gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SocialIcon, {
									href: COMPANY.social.instagram,
									icon: Instagram,
									label: "Instagram"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SocialIcon, {
									href: COMPANY.social.facebook,
									icon: Facebook,
									label: "Facebook"
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
						className: "mb-3 sm:mb-4 font-display text-sm sm:text-base font-bold text-cream",
						children: "Links Rápidos"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "space-y-2 sm:space-y-2.5",
						children: quickLinks.map((link) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: link.href,
							onClick: (e) => {
								e.preventDefault();
								handleAnchor(link.href);
							},
							className: "text-xs sm:text-sm text-slate transition-colors hover:text-gold",
							children: link.label
						}) }, link.href))
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
						className: "mb-3 sm:mb-4 font-display text-sm sm:text-base font-bold text-cream",
						children: "Seguros"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "space-y-2 sm:space-y-2.5",
						children: insuranceLinks.map((link) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs sm:text-sm text-slate",
							children: link
						}) }, link))
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
						className: "mb-3 sm:mb-4 font-display text-sm sm:text-base font-bold text-cream",
						children: "Contato"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "space-y-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-start gap-2.5 sm:gap-3 text-xs sm:text-sm text-slate",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "mt-0.5 h-4 w-4 shrink-0 text-gold" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: `tel:${COMPANY.phoneRaw}`,
									className: "transition-colors hover:text-gold",
									children: COMPANY.phone
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-start gap-2.5 sm:gap-3 text-xs sm:text-sm text-slate",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "mt-0.5 h-4 w-4 shrink-0 text-gold" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: `mailto:${COMPANY.email}`,
									className: "transition-colors hover:text-gold break-all font-medium",
									children: COMPANY.email
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-start gap-2.5 sm:gap-3 text-xs sm:text-sm text-slate",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "mt-0.5 h-4 w-4 shrink-0 text-gold" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: COMPANY.mapsUrl,
									target: "_blank",
									rel: "noopener noreferrer",
									className: "transition-colors hover:text-gold",
									children: COMPANY.address
								})]
							})
						]
					})] })
				]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "border-t border-white/10 bg-navy",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex max-w-7xl flex-col items-center justify-between gap-3 sm:gap-4 px-4 py-5 sm:py-6 sm:flex-row",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-center text-xs text-slate sm:text-left",
					children: [
						"© ",
						(/* @__PURE__ */ new Date()).getFullYear(),
						" ",
						COMPANY.name,
						". Todos os direitos reservados."
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-4 sm:gap-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: onPrivacy,
						className: "text-xs text-slate transition-colors hover:text-gold",
						children: "Política de Privacidade"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: onTerms,
						className: "text-xs text-slate transition-colors hover:text-gold",
						children: "Termos de Uso"
					})]
				})]
			})
		})]
	});
}
function SocialIcon({ href, icon: Icon, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
		href,
		target: "_blank",
		rel: "noopener noreferrer",
		className: "grid h-9 w-9 place-items-center rounded-full border border-white/10 text-slate transition-colors hover:border-gold hover:text-gold",
		"aria-label": label,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-4 w-4" })
	});
}
function PrivacyModal({ open, onClose }) {
	if (!open) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-[60] flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm",
		onClick: onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-h-[85vh] w-full max-w-2xl overflow-y-auto rounded-2xl border border-white/10 bg-navy-light p-5 sm:p-8 shadow-2xl",
			onClick: (e) => e.stopPropagation(),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 sm:mb-6 flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl sm:text-2xl font-bold text-cream",
					children: "Política de Privacidade"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: onClose,
					className: "grid h-9 w-9 place-items-center rounded-full text-slate transition-colors hover:bg-white/10 hover:text-cream",
					"aria-label": "Fechar",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-5 w-5" })
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-4 text-sm leading-relaxed text-slate",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "A Lifema Seguros valoriza a privacidade dos visitantes e clientes. Esta política descreve como coletamos, usamos e protegemos suas informações." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
						className: "text-cream",
						children: "Coleta de dados:"
					}), " podemos coletar informações pessoais como nome, telefone e e-mail quando você preenche nossos formulários de contato ou solicitação de cotação."] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
						className: "text-cream",
						children: "Uso das informações:"
					}), " as informações são utilizadas exclusivamente para entrar em contato, apresentar opções de seguros e prestar atendimento."] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
						className: "text-cream",
						children: "Proteção:"
					}), " adotamos medidas de segurança para proteger seus dados contra acesso não autorizado, alteração ou divulgação."] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
						className: "text-cream",
						children: "Cookies:"
					}), " nosso site pode utilizar cookies para melhorar a experiência de navegação. Você pode desativá-los nas configurações do navegador."] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Ao utilizar este site, você concorda com os termos desta política. Em caso de dúvidas, entre em contato conosco." })
				]
			})]
		})
	});
}
function TermsModal({ open, onClose }) {
	if (!open) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-[60] flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm",
		onClick: onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-h-[85vh] w-full max-w-2xl overflow-y-auto rounded-2xl border border-white/10 bg-navy-light p-5 sm:p-8 shadow-2xl",
			onClick: (e) => e.stopPropagation(),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 sm:mb-6 flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl sm:text-2xl font-bold text-cream",
					children: "Termos de Uso"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: onClose,
					className: "grid h-9 w-9 place-items-center rounded-full text-slate transition-colors hover:bg-white/10 hover:text-cream",
					"aria-label": "Fechar",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-5 w-5" })
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-4 text-sm leading-relaxed text-slate",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Ao acessar e usar este site, você aceita os termos e condições descritos abaixo. Se não concordar, por favor, não utilize o site." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
						className: "text-cream",
						children: "Propriedade intelectual:"
					}), " todo o conteúdo disponível neste site, incluindo textos, imagens, logotipos e marcas, é de propriedade da Lifema Seguros ou de seus licenciadores."] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
						className: "text-cream",
						children: "Uso permitido:"
					}), " o site destina-se a informar sobre produtos e serviços de seguros. É proibido o uso para fins ilegais ou que possam prejudicar a corretora ou terceiros."] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
						className: "text-cream",
						children: "Precisão das informações:"
					}), " as informações publicadas têm caráter informativo e não substituem a apólice contratada ou a consulta com um corretor."] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
						className: "text-cream",
						children: "Links externos:"
					}), " este site pode conter links para sites de terceiros. Não nos responsabilizamos pelo conteúdo ou práticas de privacidade desses sites."] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "A Lifema Seguros pode alterar estes termos a qualquer momento. Recomendamos que você os consulte periodicamente." })
				]
			})]
		})
	});
}
//#endregion
export { cn as a, TermsModal as i, Header as n, PrivacyModal as r, Footer as t };

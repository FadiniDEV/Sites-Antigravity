import { n as __toESM } from "../_runtime.mjs";
import { n as blogPosts, t as COMPANY } from "./blogPosts-CUNdaIJl.mjs";
import { n as require_jsx_runtime, r as require_react, t as QueryClientProvider } from "../_libs/react+tanstack__react-query.mjs";
import { g as MessageCircle } from "../_libs/lucide-react.mjs";
import { _ as useRouter, c as HeadContent, d as Outlet, f as lazyRouteComponent, m as createRootRouteWithContext, p as createFileRoute, s as Scripts, u as createRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-mBg_taDA.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var styles_default = "/assets/styles-BU2rh9c_.css";
function reportLovableError(error, context = {}) {
	if (typeof window === "undefined") return;
	window.__lovableEvents?.captureException?.(error, {
		source: "react_error_boundary",
		route: window.location.pathname,
		...context
	}, {
		mechanism: "react_error_boundary",
		handled: false,
		severity: "error"
	});
	const message = error instanceof Response ? `Response ${error.status}${error.url ? ` at ${error.url}` : ""}` : error instanceof Error ? error.message : String(error);
	const stack = error instanceof Error ? error.stack : void 0;
	window.__lovableReportRuntimeError?.({
		message,
		...stack !== void 0 && { stack },
		filename: window.location.pathname
	});
}
function WhatsAppButton() {
	const [tooltipVisible, setTooltipVisible] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
		href: `https://wa.me/${COMPANY.whatsappNumber}?text=${encodeURIComponent(COMPANY.whatsappDefaultMessage)}`,
		target: "_blank",
		rel: "noopener noreferrer",
		"aria-label": "Fale conosco pelo WhatsApp",
		className: "fixed bottom-4 right-4 z-50 flex items-center gap-2.5 sm:gap-3 rounded-full bg-gold p-3.5 sm:p-4 text-navy shadow-lg shadow-gold/25 transition-transform duration-300 hover:scale-110 hover:shadow-gold/40 sm:bottom-6 sm:right-6",
		onMouseEnter: () => setTooltipVisible(true),
		onMouseLeave: () => setTooltipVisible(false),
		onFocus: () => setTooltipVisible(true),
		onBlur: () => setTooltipVisible(false),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "h-5 w-5 sm:h-6 sm:w-6 shrink-0 fill-current" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: `hidden max-w-0 overflow-hidden whitespace-nowrap text-xs sm:text-sm font-semibold transition-all duration-300 sm:inline-block ${tooltipVisible ? "max-w-[10rem] pl-1" : ""}`,
			children: "Fale no WhatsApp"
		})]
	});
}
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-7xl font-bold text-foreground",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-xl font-semibold text-foreground",
					children: "Página não encontrada"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "A página que você procura não existe ou foi movida."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-lg bg-primary px-5 py-2.5 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Voltar ao início"
					})
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		reportLovableError(error, { boundary: "tanstack_root_error_component" });
	}, [error]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-xl font-semibold tracking-tight text-foreground",
					children: "Esta página não carregou"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Algo deu errado do nosso lado. Você pode tentar recarregar ou voltar ao início."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "inline-flex items-center justify-center rounded-lg bg-primary px-5 py-2.5 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Tentar novamente"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-lg border border-input bg-background px-5 py-2.5 text-sm font-medium text-foreground transition-colors hover:bg-accent",
						children: "Voltar ao início"
					})]
				})
			]
		})
	});
}
var Route$3 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "Lifema Seguros — Proteção para o que realmente importa" },
			{
				name: "description",
				content: "Corretora de seguros brasileira. Soluções personalizadas em seguro auto, residencial, vida, empresarial, saúde, viagem, moto, caminhão e frotas."
			},
			{
				name: "author",
				content: "Lifema Seguros"
			},
			{
				property: "og:title",
				content: "Lifema Seguros — Proteção para o que realmente importa"
			},
			{
				property: "og:description",
				content: "Corretora de seguros brasileira. Soluções personalizadas em seguro auto, residencial, vida, empresarial, saúde, viagem, moto, caminhão e frotas."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			},
			{
				name: "twitter:site",
				content: "@lifemaseguros"
			}
		],
		links: [
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "icon",
				type: "image/png",
				href: "/favicon.png"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Outfit:wght@400;500;600;700;800&display=swap"
			}
		]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "pt-BR",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			children,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhatsAppButton, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	});
}
function RootComponent() {
	const { queryClient } = Route$3.useRouteContext();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientProvider, {
		client: queryClient,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
	});
}
var $$splitComponentImporter$2 = () => import("./routes-4e_D7_ur.mjs");
var Route$2 = createFileRoute("/")({
	component: lazyRouteComponent($$splitComponentImporter$2, "component"),
	head: () => ({ meta: [
		{ title: "Lifema Seguros | Corretora de Seguros no Brasil" },
		{
			name: "description",
			content: "Lifema Seguros é uma corretora brasileira especializada em seguros para pessoas, famílias e empresas. Cote seguro auto, residencial, vida e mais."
		},
		{
			property: "og:title",
			content: "Lifema Seguros | Corretora de Seguros no Brasil"
		},
		{
			property: "og:description",
			content: "Proteção completa para você, sua família e sua empresa. Atendimento personalizado e cotação rápida."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] })
});
var $$splitComponentImporter$1 = () => import("./blog-C3lP0hNa.mjs");
var Route$1 = createFileRoute("/blog/")({
	component: lazyRouteComponent($$splitComponentImporter$1, "component"),
	head: () => ({ meta: [
		{ title: "Blog | Lifema Seguros — Dicas e Guias de Seguros" },
		{
			name: "description",
			content: "Leia artigos e guias práticos sobre Seguro Auto, Residencial, Vida, Empresarial e dicas de proteção financeira da Lifema Seguros."
		},
		{
			property: "og:title",
			content: "Blog & Artigos | Lifema Seguros"
		},
		{
			property: "og:description",
			content: "Informação é proteção. Descubra os melhores conteúdos para proteger sua família, patrimônio e negócios."
		}
	] })
});
var $$splitComponentImporter = () => import("../_slug-Cnmni_aC.mjs");
var Route = createFileRoute("/blog/$slug")({
	component: lazyRouteComponent($$splitComponentImporter, "component"),
	head: ({ params }) => {
		const post = blogPosts.find((p) => p.slug === params.slug);
		if (!post) return { meta: [{ title: "Artigo não encontrado | Lifema Seguros" }] };
		return { meta: [
			{ title: `${post.title} | Blog Lifema Seguros` },
			{
				name: "description",
				content: post.excerpt
			},
			{
				property: "og:title",
				content: post.title
			},
			{
				property: "og:description",
				content: post.excerpt
			},
			{
				property: "og:type",
				content: "article"
			}
		] };
	}
});
var IndexRoute = Route$2.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$3
});
var BlogIndexRoute = Route$1.update({
	id: "/blog/",
	path: "/blog/",
	getParentRoute: () => Route$3
});
var rootRouteChildren = {
	IndexRoute,
	BlogSlugRoute: Route.update({
		id: "/blog/$slug",
		path: "/blog/$slug",
		getParentRoute: () => Route$3
	}),
	BlogIndexRoute
};
var routeTree = Route$3._addFileChildren(rootRouteChildren)._addFileTypes();
var getRouter = () => {
	return createRouter({
		routeTree,
		context: { queryClient: new QueryClient() },
		scrollRestoration: true,
		defaultPreloadStaleTime: 0
	});
};
//#endregion
export { getRouter };

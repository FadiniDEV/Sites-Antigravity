//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DyfWFm2g.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/Users/conta/Documents/Sites Antigravity/lifema-seguros-premium/src/routes/__root.tsx",
		children: [
			"/",
			"/blog/$slug",
			"/blog/"
		],
		preloads: ["/assets/index-FTFl7bOT.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-FTFl7bOT.js"
		} }]
	},
	"/": {
		filePath: "C:/Users/conta/Documents/Sites Antigravity/lifema-seguros-premium/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-Lj6V0XYE.js", "/assets/TermsModal-Bf18P88a.js"]
	},
	"/blog/$slug": {
		filePath: "C:/Users/conta/Documents/Sites Antigravity/lifema-seguros-premium/src/routes/blog/$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/_slug-B5_ikYhI.js",
			"/assets/TermsModal-Bf18P88a.js",
			"/assets/clock-BCduV_yT.js"
		]
	},
	"/blog/": {
		filePath: "C:/Users/conta/Documents/Sites Antigravity/lifema-seguros-premium/src/routes/blog/index.tsx",
		children: void 0,
		preloads: [
			"/assets/blog-3YPA2Ks4.js",
			"/assets/TermsModal-Bf18P88a.js",
			"/assets/clock-BCduV_yT.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };

# Lifema Seguros Premium

Crie um site completo, moderno e premium para uma corretora de seguros brasileira chamada LIFEMA SEGUROS.

REFERÊNCIAS VISUAIS OBRIGATÓRIAS

A primeira imagem anexada é a principal referência visual do projeto. Quero reproduzir a mesma linguagem visual, composição, proporções, sensação de profundidade e organização das seções, porém criando um site original para uma corretora de seguros.

A segunda imagem anexada é a logo oficial da LIFEMA SEGUROS. Utilize essa logo no site sem redesenhá-la, distorcê-la ou modificar suas proporções.

NÃO crie um site genérico de seguradora. Quero uma adaptação visual muito próxima da primeira referência, substituindo completamente o conteúdo de tecnologia/IT pelo universo de seguros.

ESTILO VISUAL

Use como base:

Fundo azul-marinho extremamente escuro;

Azul profundo como cor secundária;

Amarelo/dourado da logo como cor de destaque;

Branco para textos principais;

Containers grandes e bem definidos;

Cards escuros com contraste sutil;

Bordas arredondadas;

Sombras suaves;

Gradientes discretos;

Elementos sobrepostos;

Layout assimétrico e sofisticado;

Imagens grandes;

Tipografia moderna e pesada nos títulos;

Muito espaço negativo;

Pequenos detalhes amarelos para direcionar atenção.

A aparência deve transmitir segurança, confiança, sofisticação e profissionalismo.

Evite aparência de template pronto, excesso de elementos, excesso de gradientes ou visual excessivamente futurista.

HEADER

Crie um header semelhante ao da primeira imagem.

Logo Lifema Seguros à esquerda.

Menu:

Início

Sobre Nós

Seguros

Benefícios

Blog

Contato

À direita, botão amarelo:
Solicitar Cotação

O header deve ser transparente/escuro inicialmente e possuir efeito de mudança sutil ao rolar.

HERO

Crie uma seção Hero grande e visualmente impactante, inspirada diretamente na composição da primeira imagem.

Utilize uma fotografia profissional relacionada a proteção, família, patrimônio, automóvel ou negócios.

Aplicar overlay azul-marinho/amarelo sobre a imagem.

Título grande:

"Proteção para o que realmente importa."

Texto:

"Na Lifema Seguros, encontramos soluções para proteger seu patrimônio, sua família, seu veículo e sua empresa."

Botões:

Solicitar Cotação
Conheça nossos Seguros

Adicionar pequenos indicadores visuais abaixo do Hero, como:
Atendimento Personalizado
Soluções Sob Medida
Proteção para diferentes momentos

SEÇÃO INSTITUCIONAL

Reproduza a lógica visual da seção "About Us" da referência: imagem grande de um lado e conteúdo do outro.

Título:

"Seguro certo começa com orientação certa."

Explique que a Lifema Seguros auxilia clientes na busca por soluções de proteção adequadas às suas necessidades.

Botão:
Conheça a Lifema

SEÇÃO DE SEGUROS

Criar uma seção visual semelhante à área de cards da referência.

Título:

"Proteção para cada necessidade."

Criar cards modernos para:

Seguro Auto

Seguro Residencial

Seguro de Vida

Seguro Empresarial

Seguro Saúde

Seguro Viagem

Seguro Moto

Seguro Caminhão

Seguro para Frotas

Cada card deve possuir ícone, imagem ou elemento visual, título, descrição curta e botão "Saiba mais".

DIFERENCIAIS

Título:

"Por que escolher a Lifema?"

Criar cards para:

Atendimento Personalizado
Entendemos seu perfil e suas necessidades.

Soluções Sob Medida
Buscamos alternativas adequadas para cada cliente.

Diversas Opções
Compare possibilidades antes de tomar sua decisão.

Acompanhamento
Suporte durante sua jornada com o seguro.

COMO FUNCIONA

Criar uma seção visual com quatro etapas:

01 — Conte o que você precisa
02 — Analisamos seu perfil
03 — Apresentamos as opções
04 — Você escolhe com segurança

Usar números grandes e amarelos como elemento visual.

CTA

Criar uma faixa de destaque semelhante à faixa roxa presente na referência, mas usando azul-marinho + amarelo.

Título:

"Proteja hoje o que importa amanhã."

Botão:
Solicitar Cotação

DEPOIMENTOS

Criar seção de depoimentos visualmente semelhante à referência.

Não inventar clientes reais. Utilizar conteúdo demonstrativo claramente marcado ou placeholders para posterior substituição.

BLOG

Criar seção:

"Informação também é proteção."

Cards para artigos sobre:

Como escolher um seguro auto;

Seguro residencial;

Seguro de vida;

Seguro empresarial;

O que analisar antes de contratar um seguro.

FAQ

Criar accordion com perguntas frequentes sobre contratação, cotação, tipos de seguros, atendimento e funcionamento de uma corretora.

CONTATO

Criar seção moderna com formulário:

Nome
Telefone
E-mail
Tipo de Seguro
Mensagem

Botão:
Solicitar Cotação

Adicionar placeholders para:
[WhatsApp]
[Telefone]
[E-mail]
[Endereço]

FOOTER

Reproduzir a lógica visual do footer da primeira imagem, adaptando para Lifema Seguros.

Incluir:

Logo;

Descrição;

Links rápidos;

Seguros;

Contato;

Redes sociais;

Política de Privacidade;

Termos de Uso.

TECNOLOGIA

Não utilizar WordPress, Elementor ou qualquer tema WordPress.

Desenvolver como aplicação web moderna usando:

React

TypeScript

Vite

Tailwind CSS

Componentes reutilizáveis

Lucide Icons ou biblioteca equivalente

Organizar o código de forma limpa e profissional.

Criar componentes independentes para Header, Hero, InsuranceCard, Benefits, ProcessSteps, Testimonials, BlogCards, FAQ, Contact e Footer.

RESPONSIVIDADE

O site precisa ser excelente em:

Desktop;

Notebook;

Tablet;

Smartphone.

No mobile, reorganizar completamente os elementos quando necessário. Não simplesmente reduzir o desktop.

ANIMAÇÕES

Adicionar animações suaves e profissionais:

Fade-in;

Slide-up;

Hover nos cards;

Transições nos botões;

Parallax muito sutil no Hero;

Animações de entrada ao rolar.

Nada exagerado.

REGRA MAIS IMPORTANTE

A primeira imagem deve ser usada como referência visual principal para o layout.

Quero que o resultado tenha a mesma sensação visual da referência: site corporativo premium, escuro, elegante, com grandes blocos, imagens sobrepostas, cards, profundidade e composição sofisticada.

A identidade deve ser completamente transformada para LIFEMA SEGUROS, utilizando a logo da segunda imagem e suas cores de azul-marinho e amarelo/dourado.

Não faça apenas uma landing page simples. Crie um site completo, visualmente rico e profissional.

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://lifema-seguros-premium.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/ee513c60-82eb-4de9-ac39-d15d42d725d9).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```

# Campinense Seguros — site corporativo premium

Site de página única (`/`), com todas as seções na mesma página e o menu navegando por âncoras com rolagem suave. Linguagem visual da referência: azul-marinho muito escuro, blocos grandes, cards escuros, imagens sobrepostas e detalhes em dourado.

## Identidade visual

- Paleta em tokens: fundo `#0B1020`-like (navy quase preto), azul profundo secundário, dourado da logo como destaque, branco/cinza-claro para textos.
- Tipografia moderna e pesada nos títulos (display) + sans neutra no corpo, carregada via `<link>` no root.
- Cantos arredondados, sombras suaves, gradientes discretos, muito espaço negativo.
- Logo oficial usada como está (sem redesenho), publicada como asset CDN; favicon quadrado gerado a partir dela.

## Estrutura da página inicial

1. **Header** — barra superior escura com contato/redes, logo à esquerda, menu (Início, Sobre Nós, Seguros, Benefícios, Blog, Contato, Cotação de Seguros), botão dourado "Solicitar Cotação". Transparente no topo, com fundo sólido e sombra sutil ao rolar. Menu mobile em drawer. O último item do menu, "Cotação de Seguros", destaca-se visualmente e abre o link externo `https://campinense.aggilizador.com.br/` em nova aba (`target="_blank"`, `rel="noopener noreferrer"`).
2. **Hero** — imagem grande com overlay navy/dourado, parallax sutil, título "Proteção para o que realmente importa.", subtítulo, dois botões e três indicadores abaixo.
3. **Institucional** — imagem grande de um lado, texto do outro: "Seguro certo começa com orientação certa." + botão "Conheça a Campinense".
4. **Seguros** — grade de 9 cards (Auto, Residencial, Vida, Empresarial, Saúde, Viagem, Moto, Caminhão, Frotas) com ícone, título, descrição curta e "Saiba mais".
5. **Diferenciais** — "Por que escolher a Campinense?" com 4 cards.
6. **Como funciona** — 4 etapas com números grandes em dourado.
7. **Faixa CTA** — banda navy + dourado: "Proteja hoje o que importa amanhã." + botão.
8. **Depoimentos** — carrossel/slider no estilo da referência, com conteúdo claramente marcado como demonstrativo (placeholder para substituição).
9. **Blog** — 5 cards de artigos com categoria, data e título.
10. **FAQ** — accordion com perguntas sobre cotação, contratação, tipos de seguro, atendimento e papel da corretora.
11. **Contato** — formulário (Nome, Telefone, E-mail, Tipo de Seguro, Mensagem) + blocos de placeholder para WhatsApp, Telefone, E-mail e Endereço. Envio apenas com validação e feedback visual (sem backend nesta etapa).
12. **Botão flutuante de WhatsApp** — fixado no canto inferior direito em todas as páginas, ícone de WhatsApp (Lucide), cor dourada com sombra, abre o link oficial do WhatsApp; mostra tooltip em desktop e é discreto em mobile. Incluído no layout root para aparecer em todas as rotas.
13. **Footer** — logo, descrição, links rápidos, seguros, contato, redes sociais, Política de Privacidade e Termos de Uso.

## Navegação (página única)

- Cada seção recebe um `id`: `inicio`, `sobre`, `seguros`, `beneficios`, `blog`, `contato`.
- Menu do header e links do footer usam âncoras (`#id`) com rolagem suave e compensação da altura do header fixo.
- Item de menu ativo destacado conforme a seção visível (IntersectionObserver).
- Política de Privacidade e Termos de Uso abrem em modal na própria página, sem criar rotas extras.
- SEO na rota `/`: `head()` com título, descrição, og e twitter próprios da Campinense Seguros.

## Detalhes técnicos

- TanStack Start + React + TypeScript + Vite + Tailwind v4 (stack já do projeto); ícones Lucide.
- Tokens de cor/tipografia definidos em `src/styles.css` (`@theme inline`, oklch). Nenhuma cor hardcoded nos componentes.
- Componentes independentes em `src/components/`: `Header`, `Hero`, `About`, `InsuranceCard` + `InsuranceGrid`, `Benefits`, `ProcessSteps`, `CtaBand`, `Testimonials`, `BlogCards`, `FAQ`, `Contact`, `Footer`.
- Hook `useReveal` (IntersectionObserver) para fade-in / slide-up ao rolar; transições em hover de cards e botões; parallax leve no hero via transform no scroll. Respeita `prefers-reduced-motion`.
- Responsividade real: grids que reorganizam em tablet/mobile, header em drawer, hero recomposto, cards em coluna única.
- Imagens: fotografias geradas (hero, institucional, cards de blog) salvas em `src/assets`; logo via pointer de asset.
- Sem WordPress/Elementor; sem backend nesta etapa.

## Fora do escopo desta etapa

- Envio real do formulário (e-mail/banco) e páginas individuais de cada seguro/artigo — podem ser adicionados depois.
